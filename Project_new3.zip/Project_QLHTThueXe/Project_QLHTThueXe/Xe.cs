﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    public partial class frmXe : Form
    {
        public frmXe()
        {
            InitializeComponent();
        }

        clsDataBase db = new clsDataBase();
        private void Xe_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (r == DialogResult.No)
                e.Cancel = true;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
     
        /*
        private void txtNH_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNH, "Bạn phải nhập Nhãn Hiệu ");
            else
                this.errorProvider1.Clear();
        }

        private void txtXe_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtXe, "Bạn phải nhập Tên Xe ");
            else
                this.errorProvider1.Clear();
        }

        private void txtBienSo_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtBienSo, "Bạn phải nhập Biển Số ");
            else
                this.errorProvider1.Clear();
        }
        */
 


        private void Xe_Load(object sender, EventArgs e)
        {
            drvXe.DataSource = db.getDataTable("XE");
        }

        private void thoatToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void LayDSXe()
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-0BMTT7L;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_LayDsXE", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                // sqldataAdapter
                SqlDataAdapter daXe = new SqlDataAdapter(cmd);
                DataTable dtXe = new DataTable();
                daXe.Fill(dtXe);
                drvXe.DataSource = dtXe;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-0BMTT7L;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themXe", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));
                cmd.Parameters.Add(new SqlParameter("@NHANHIEU", txtNH.Text));
                cmd.Parameters.Add(new SqlParameter("@TENXE", txtXe.Text));
                cmd.Parameters.Add(new SqlParameter("@BIENSO", txtBienSo.Text));
                cmd.Parameters.Add(new SqlParameter("@LOAIXE", txtLX.Text));
                cmd.Parameters.Add(new SqlParameter("@DIACHIBAIXE", cbBX.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", cbTT.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                MessageBox.Show("Them thanh cong");
                LayDSXe();
                }
                else
                {
                    MessageBox.Show("Khong thanh cong");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                //MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

      
    }
}
