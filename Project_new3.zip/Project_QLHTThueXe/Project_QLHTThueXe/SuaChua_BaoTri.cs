﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
namespace Project_QLHTThueXe
{
    public partial class frmSuaChua : Form
    {
        public frmSuaChua()
        {
            InitializeComponent();
        }

        private void SuaChua_BaoTri_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel = true;
        }
        private void txtMhd_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
            {
                this.errorProvider1.SetError(txtMhd, "You must enter Your Mhd");

            }
            else
                this.errorProvider1.Clear();
        }

        private void txtNcc_Leave(object sender, EventArgs e)
        {
             Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length == 0 )
                {
                    this.errorProvider1.SetError(txtNcc, "You must enter your nha cung cap");

                }
                else
                    this.errorProvider1.Clear();
           
           
        }

        private void txtMs_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtMs, "You must enter your number");
            else
                this.errorProvider1.Clear();
        }

        private void txtNd_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNd, "You must enter your text");
            else
                this.errorProvider1.Clear();
        }

        private void txtTt_Leave(object sender, EventArgs e)
        {
                        Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtTt, "This is not invalid number");
            else
                this.errorProvider1.Clear();


        }

        private void thoa1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void LayDSXe()
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-0BMTT7L;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_LayDsSC", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                // sqldataAdapter
                SqlDataAdapter daSC = new SqlDataAdapter(cmd);
                DataTable dtSC = new DataTable();

                daSC.Fill(dtSC);
                drvSC.DataSource = dtSC;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

       /* private void btnThem_Click(object sender, EventArgs e)
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-0BMTT7L;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themSuaChua", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAHOADON", txtMhd.Text));
                cmd.Parameters.Add(new SqlParameter("@NHACUNGCAP", txtNH.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYSUACHUA", txtXe.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYHOANTAT", txtBienSo.Text));
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NOIDUNGCHITIET", cbBX.Text));
                cmd.Parameters.Add(new SqlParameter("@TONGTIEN", cbTT.Text));
                cmd.Parameters.Add(new SqlParameter("@THANHTOAN", cbTT.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Them thanh cong");
                    LayDSXe();
                }
                else
                {
                    MessageBox.Show("Khong thanh cong");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }*/

    

        

        

       
       
        //private void btnL_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        SaveFileDialog saveFileDialog1 = new SaveFileDialog();
        //        if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        //        {
        //            string path = saveFileDialog1.FileName;
        //            StreamWriter savefile = new StreamWriter(path);
        //            foreach (ListViewItem i in this.lvData.Items)
        //            {
        //                savefile.WriteLine(i.SubItems[0].Text + "-" + i.SubItems[1].Text + "-" + i.SubItems[2].Text + "-" + i.SubItems[3].Text + "-" + i.SubItems[4].Text);
        //            }
        //            savefile.Flush();
        //            savefile.Close();
        //            savefile.Dispose();
        //        }
        //    }
        //    catch (IOException ioex)
        //    {
        //        MessageBox.Show(ioex.Message);
        //    }
        //}

       

        
    }
}
