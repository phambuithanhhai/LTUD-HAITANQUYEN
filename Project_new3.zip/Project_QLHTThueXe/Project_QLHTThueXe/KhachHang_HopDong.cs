﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    public partial class frmHopDong : Form
    {
        public frmHopDong()
        {
            InitializeComponent();
        }

        private void frmHopDong_FormClosing(object sender, FormClosingEventArgs e)
        {
           if( MessageBox.Show("Bạn có muốn thoát không?","Thông báo",MessageBoxButtons.YesNo,MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel =true;
        }
        private void thoatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSP_TextChanged(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtSP, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();

        }

        private void txtSoHD_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtSoHD, "Bạn phãi nhập Số HD");
            else
                this.errorProvider1.Clear();
        }

        private void txtTen_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtTen, "Bạn phải nhập Tên KH");
            else
                this.errorProvider1.Clear();
        }

        private void txtMSThue_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtMSThue, "Bạn phải nhập Mã Số Thuế");
            else
                this.errorProvider1.Clear();
        }

        private void txtDiaChi_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtDiaChi, "Bạn phải nhập Địa chỉ");
            else
                this.errorProvider1.Clear();
        }

        private void txtSDT_TextChanged(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtSDT, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }

        private void txtNgheNghiep_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNgheNghiep, "Bạn phải nhập Nghề Nghiệp");
            else
                this.errorProvider1.Clear();
        }

        private void txtCMND_TextChanged(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtCMND, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }
        private void txtGPLX_TextChanged(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtGPLX, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }

        private void txtNoiCapCMND_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNoiCapCMND, "Bạn phải nhập Nơi Cấp CMND");
            else
                this.errorProvider1.Clear();
        }

        private void txtNoiCapGPLX_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNoiCapGPLX, "Bạn phải nhập Nơi Cấp");
            else
                this.errorProvider1.Clear();
        }

        private void frmHopDong_Load(object sender, EventArgs e)
        {

        }

    



      

      

      

     


   

       


      

      

    }
}
