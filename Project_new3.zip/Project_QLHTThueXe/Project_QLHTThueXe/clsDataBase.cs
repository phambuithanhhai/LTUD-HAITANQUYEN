﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    class clsDataBase
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-0BMTT7L;Initial Catalog=QLOTO;Integrated Security=True");
        public DataTable getDataTable(string NameTable)
        {
            string sql = "select * from " + NameTable;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}
