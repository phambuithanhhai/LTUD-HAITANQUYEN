﻿namespace Project_QLHTThueXe
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Khách hàng thuê xe lẻ");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Khách hàng thuê xe tháng");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Thời hạn");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Trạng thái ");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Danh mục xe");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Xuất xứ");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Hình thức thanh toán");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Thời hạn xe");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Danh mục dùng chung", new System.Windows.Forms.TreeNode[] {
            treeNode18,
            treeNode19,
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode23,
            treeNode24,
            treeNode25});
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Nhà cung cấp");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Nội dung sửa chữa");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Vật tư");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Thông tin sửa chữa", new System.Windows.Forms.TreeNode[] {
            treeNode27,
            treeNode28,
            treeNode29});
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Danh Mục", new System.Windows.Forms.TreeNode[] {
            treeNode26,
            treeNode30});
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Quản Lý Kinh Doanh Xe");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Sửa Chữa - Bảo Dưỡng");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Báo Cáo");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.dangnhapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tExit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmMớiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hopDongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suaChuaBaoTriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gioiThieuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.listView1 = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.thêmMớiToolStripMenuItem,
            this.gioiThieuToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
            this.menuStrip2.Size = new System.Drawing.Size(990, 29);
            this.menuStrip2.TabIndex = 9;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dangnhapToolStripMenuItem,
            this.thoátToolStripMenuItem,
            this.tExit});
            this.toolStripMenuItem7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(91, 23);
            this.toolStripMenuItem7.Text = "Hệ Thống";
            // 
            // dangnhapToolStripMenuItem
            // 
            this.dangnhapToolStripMenuItem.Name = "dangnhapToolStripMenuItem";
            this.dangnhapToolStripMenuItem.Size = new System.Drawing.Size(155, 24);
            this.dangnhapToolStripMenuItem.Text = "Đăng nhập";
            this.dangnhapToolStripMenuItem.Click += new System.EventHandler(this.dangnhapToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(155, 24);
            this.thoátToolStripMenuItem.Text = "Lưu";
            // 
            // tExit
            // 
            this.tExit.Name = "tExit";
            this.tExit.Size = new System.Drawing.Size(155, 24);
            this.tExit.Text = "Thoát";
            this.tExit.Click += new System.EventHandler(this.tExit_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(95, 23);
            this.toolStripMenuItem8.Text = "Thông Tin";
            // 
            // thêmMớiToolStripMenuItem
            // 
            this.thêmMớiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hopDongToolStripMenuItem,
            this.xeToolStripMenuItem,
            this.suaChuaBaoTriToolStripMenuItem});
            this.thêmMớiToolStripMenuItem.Name = "thêmMớiToolStripMenuItem";
            this.thêmMớiToolStripMenuItem.Size = new System.Drawing.Size(94, 23);
            this.thêmMớiToolStripMenuItem.Text = "Thêm mới";
            // 
            // hopDongToolStripMenuItem
            // 
            this.hopDongToolStripMenuItem.Name = "hopDongToolStripMenuItem";
            this.hopDongToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.hopDongToolStripMenuItem.Text = "Hợp Đồng";
            this.hopDongToolStripMenuItem.Click += new System.EventHandler(this.hopDongToolStripMenuItem_Click);
            // 
            // xeToolStripMenuItem
            // 
            this.xeToolStripMenuItem.Name = "xeToolStripMenuItem";
            this.xeToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.xeToolStripMenuItem.Text = "Xe";
            this.xeToolStripMenuItem.Click += new System.EventHandler(this.xeToolStripMenuItem_Click);
            // 
            // suaChuaBaoTriToolStripMenuItem
            // 
            this.suaChuaBaoTriToolStripMenuItem.Name = "suaChuaBaoTriToolStripMenuItem";
            this.suaChuaBaoTriToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.suaChuaBaoTriToolStripMenuItem.Text = "Sửa Chữa - Bảo Trì";
            this.suaChuaBaoTriToolStripMenuItem.Click += new System.EventHandler(this.suaChuaBaoTriToolStripMenuItem_Click);
            // 
            // gioiThieuToolStripMenuItem
            // 
            this.gioiThieuToolStripMenuItem.Name = "gioiThieuToolStripMenuItem";
            this.gioiThieuToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.gioiThieuToolStripMenuItem.Text = "Giới thiệu";
            this.gioiThieuToolStripMenuItem.Click += new System.EventHandler(this.gioiThieuToolStripMenuItem_Click);
            // 
            // treeView1
            // 
            this.treeView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.treeView1.ImageIndex = 1;
            this.treeView1.ImageList = this.imageList;
            this.treeView1.LabelEdit = true;
            this.treeView1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.treeView1.Location = new System.Drawing.Point(0, 84);
            this.treeView1.Name = "treeView1";
            treeNode18.ImageIndex = 6;
            treeNode18.Name = "Node4";
            treeNode18.Text = "Khách hàng thuê xe lẻ";
            treeNode19.ImageIndex = 6;
            treeNode19.Name = "Node5";
            treeNode19.Text = "Khách hàng thuê xe tháng";
            treeNode20.ImageIndex = 6;
            treeNode20.Name = "Node8";
            treeNode20.Text = "Thời hạn";
            treeNode21.ImageIndex = 6;
            treeNode21.Name = "Node9";
            treeNode21.Text = "Trạng thái ";
            treeNode22.ImageIndex = 6;
            treeNode22.Name = "Node10";
            treeNode22.Text = "Danh mục xe";
            treeNode23.ImageIndex = 6;
            treeNode23.Name = "Node11";
            treeNode23.Text = "Xuất xứ";
            treeNode24.ImageIndex = 6;
            treeNode24.Name = "Node12";
            treeNode24.Text = "Hình thức thanh toán";
            treeNode25.ImageIndex = 6;
            treeNode25.Name = "Node13";
            treeNode25.Text = "Thời hạn xe";
            treeNode26.ImageIndex = 3;
            treeNode26.Name = "nDanhMucDungChung";
            treeNode26.Text = "Danh mục dùng chung";
            treeNode27.ImageIndex = 6;
            treeNode27.Name = "Node0";
            treeNode27.Text = "Nhà cung cấp";
            treeNode28.ImageIndex = 6;
            treeNode28.Name = "Node2";
            treeNode28.Text = "Nội dung sửa chữa";
            treeNode29.ImageIndex = 6;
            treeNode29.Name = "Node3";
            treeNode29.Text = "Vật tư";
            treeNode30.ImageKey = "file-manager.jpg";
            treeNode30.Name = "nThongTinSuaChua";
            treeNode30.Text = "Thông tin sửa chữa";
            treeNode31.Name = "nDanhMuc";
            treeNode31.Text = "Danh Mục";
            treeNode32.Name = "Node0";
            treeNode32.Text = "Quản Lý Kinh Doanh Xe";
            treeNode33.Name = "Node1";
            treeNode33.Text = "Sửa Chữa - Bảo Dưỡng";
            treeNode34.Name = "Node2";
            treeNode34.Text = "Báo Cáo";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode31,
            treeNode32,
            treeNode33,
            treeNode34});
            this.treeView1.SelectedImageIndex = 7;
            this.treeView1.ShowPlusMinus = false;
            this.treeView1.Size = new System.Drawing.Size(535, 895);
            this.treeView1.TabIndex = 12;
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "Archive-manage-icon.png");
            this.imageList.Images.SetKeyName(1, "Documents-icon (1).png");
            this.imageList.Images.SetKeyName(2, "Documents-icon.png");
            this.imageList.Images.SetKeyName(3, "file-manager.jpg");
            this.imageList.Images.SetKeyName(4, "fix-it-icon.png");
            this.imageList.Images.SetKeyName(5, "Hopstarter-Mac-Folders-Documents.ico");
            this.imageList.Images.SetKeyName(6, "Book-icon.png");
            this.imageList.Images.SetKeyName(7, "Car-icon.png");
            this.imageList.Images.SetKeyName(8, "Artdesigner-Urban-Stories-Car.ico");
            // 
            // listView1
            // 
            this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listView1.Location = new System.Drawing.Point(406, 84);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(705, 895);
            this.listView1.TabIndex = 13;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(406, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 31);
            this.label1.TabIndex = 15;
            this.label1.Text = "Quản Lý Hệ Thống Thuê Xe";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(990, 718);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.menuStrip2);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Hệ Thống Thuê Xe";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ToolStripMenuItem dangnhapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem thêmMớiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hopDongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suaChuaBaoTriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gioiThieuToolStripMenuItem;

    }
}

