﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project_QLHTThueXe
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r;
            r = MessageBox.Show("Bạn có muốn thoát không?", "Thông Báo",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button1);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
        private void tExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void dangnhapToolStripMenuItem_Click(object sender, EventArgs e)
        {
                frmDangNhap dn2 = new frmDangNhap();
                dn2.Show();    
        }

     
        private void hopDongToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHopDong hd = new frmHopDong();
            hd.Show();
        }

        private void xeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmXe xe = new frmXe();
            xe.Show();
        }

        private void suaChuaBaoTriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuaChua sc = new frmSuaChua();
            sc.Show();
        }

        private void gioiThieuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string kq = "";
            kq += "Phần mềm quản lí cho thuê xe ô tô\n";
            kq += "Website: Congtyphanmem.com\n";
            kq += "Design: Congtyphanmem\n";
            kq += "SDT: 0123456789\n";
            kq += "Địa chỉ: 23 Võ Văn Ngân, Phường Linh Chiểu, Quận Thủ Đức, Tp. Hồ Chí Minh";

            MessageBox.Show(kq,"Thông tin");
        }


 

        
    }
}
