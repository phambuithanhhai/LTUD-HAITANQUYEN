﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project_QLHTThueXe
{
    public partial class frmXe : Form
    {
        public frmXe()
        {
            InitializeComponent();
        }
        private void Xe_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (r == DialogResult.No)
                e.Cancel = true;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnLuu_Click(object sender, EventArgs e)
        {
             Control ctr = (Control)sender;
             if (txtXe.Text == "" || txtBienSo.Text == "" || txtBaiXe.Text == "" || txtNH.Text == "")
                 MessageBox.Show("Bạn phải nhập tất cả dữ liệu!!!");
             else
                 MessageBox.Show("Lưu thành công");
        }

        private void txtNH_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNH, "Bạn phải nhập Nhãn Hiệu ");
            else
                this.errorProvider1.Clear();
        }

        private void txtXe_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtXe, "Bạn phải nhập Tên Xe ");
            else
                this.errorProvider1.Clear();
        }

        private void txtBienSo_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtBienSo, "Bạn phải nhập Biển Số ");
            else
                this.errorProvider1.Clear();
        }

        private void txtBaiXe_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtBaiXe, "Bạn phải nhập Địa chỉ bãi xe ");
            else
                this.errorProvider1.Clear();
        }


        private void Xe_Load(object sender, EventArgs e)
        {

        }

        private void thoatToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      

      
    }
}
