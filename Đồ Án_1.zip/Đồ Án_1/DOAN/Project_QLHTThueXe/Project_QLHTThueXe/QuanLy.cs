﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project_QLHTThueXe
{
    public partial class frmQuanLy : Form
    {
        clsDataBase db = new clsDataBase();
        public frmQuanLy()
        {
            InitializeComponent();
        }

        private void hopDongToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHopDong hd = new frmHopDong();
            hd.Show();
        }

        private void xeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmXe xe = new frmXe();
            xe.Show();
        }

        private void suaChuaBaoTriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuaChua sc = new frmSuaChua();
            sc.Show();
        }

        

        private void frmQuanLy_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'qLOTODataSet.XE' table. You can move, or remove it, as needed.
            this.xETableAdapter.Fill(this.qLOTODataSet.XE);
            dgv.DataSource = db.getDataTable("XE");

        }

        private void frmQuanLy_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel = true;
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

 


        }
    }

   
   

       
       

