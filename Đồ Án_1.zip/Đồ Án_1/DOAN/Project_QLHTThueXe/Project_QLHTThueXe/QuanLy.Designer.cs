﻿namespace Project_QLHTThueXe
{
    partial class frmQuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.themToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hopDongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suaChuaBaoTriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.xEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qLOTODataSet = new Project_QLHTThueXe.QLOTODataSet();
            this.xETableAdapter = new Project_QLHTThueXe.QLOTODataSetTableAdapters.XETableAdapter();
            this.mASOXEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nHANHIEUDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tENXEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bIENSODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOAIXEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dIACHIBAIXEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tINHTRANGDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLOTODataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(302, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 31);
            this.label1.TabIndex = 18;
            this.label1.Text = "Quản Lý Hệ Thống Thuê Xe";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.themToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
            this.menuStrip2.Size = new System.Drawing.Size(959, 29);
            this.menuStrip2.TabIndex = 19;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // themToolStripMenuItem
            // 
            this.themToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hopDongToolStripMenuItem,
            this.xeToolStripMenuItem,
            this.suaChuaBaoTriToolStripMenuItem});
            this.themToolStripMenuItem.Name = "themToolStripMenuItem";
            this.themToolStripMenuItem.Size = new System.Drawing.Size(94, 23);
            this.themToolStripMenuItem.Text = "Thêm mới";
            // 
            // hopDongToolStripMenuItem
            // 
            this.hopDongToolStripMenuItem.Name = "hopDongToolStripMenuItem";
            this.hopDongToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.hopDongToolStripMenuItem.Text = "Hợp Đồng";
            this.hopDongToolStripMenuItem.Click += new System.EventHandler(this.hopDongToolStripMenuItem_Click);
            // 
            // xeToolStripMenuItem
            // 
            this.xeToolStripMenuItem.Name = "xeToolStripMenuItem";
            this.xeToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.xeToolStripMenuItem.Text = "Xe";
            this.xeToolStripMenuItem.Click += new System.EventHandler(this.xeToolStripMenuItem_Click);
            // 
            // suaChuaBaoTriToolStripMenuItem
            // 
            this.suaChuaBaoTriToolStripMenuItem.Name = "suaChuaBaoTriToolStripMenuItem";
            this.suaChuaBaoTriToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.suaChuaBaoTriToolStripMenuItem.Text = "Sửa Chữa - Bảo Trì";
            this.suaChuaBaoTriToolStripMenuItem.Click += new System.EventHandler(this.suaChuaBaoTriToolStripMenuItem_Click);
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AutoGenerateColumns = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mASOXEDataGridViewTextBoxColumn,
            this.nHANHIEUDataGridViewTextBoxColumn,
            this.tENXEDataGridViewTextBoxColumn,
            this.bIENSODataGridViewTextBoxColumn,
            this.lOAIXEDataGridViewTextBoxColumn,
            this.dIACHIBAIXEDataGridViewTextBoxColumn,
            this.tINHTRANGDataGridViewTextBoxColumn});
            this.dgv.DataSource = this.xEBindingSource;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgv.Location = new System.Drawing.Point(0, 109);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.Size = new System.Drawing.Size(959, 441);
            this.dgv.TabIndex = 20;
            // 
            // xEBindingSource
            // 
            this.xEBindingSource.DataMember = "XE";
            this.xEBindingSource.DataSource = this.qLOTODataSet;
            // 
            // qLOTODataSet
            // 
            this.qLOTODataSet.DataSetName = "QLOTODataSet";
            this.qLOTODataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // xETableAdapter
            // 
            this.xETableAdapter.ClearBeforeFill = true;
            // 
            // mASOXEDataGridViewTextBoxColumn
            // 
            this.mASOXEDataGridViewTextBoxColumn.DataPropertyName = "MASOXE";
            this.mASOXEDataGridViewTextBoxColumn.HeaderText = "MASOXE";
            this.mASOXEDataGridViewTextBoxColumn.Name = "mASOXEDataGridViewTextBoxColumn";
            this.mASOXEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nHANHIEUDataGridViewTextBoxColumn
            // 
            this.nHANHIEUDataGridViewTextBoxColumn.DataPropertyName = "NHANHIEU";
            this.nHANHIEUDataGridViewTextBoxColumn.HeaderText = "NHANHIEU";
            this.nHANHIEUDataGridViewTextBoxColumn.Name = "nHANHIEUDataGridViewTextBoxColumn";
            this.nHANHIEUDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tENXEDataGridViewTextBoxColumn
            // 
            this.tENXEDataGridViewTextBoxColumn.DataPropertyName = "TENXE";
            this.tENXEDataGridViewTextBoxColumn.HeaderText = "TENXE";
            this.tENXEDataGridViewTextBoxColumn.Name = "tENXEDataGridViewTextBoxColumn";
            this.tENXEDataGridViewTextBoxColumn.ReadOnly = true;
            this.tENXEDataGridViewTextBoxColumn.Width = 316;
            // 
            // bIENSODataGridViewTextBoxColumn
            // 
            this.bIENSODataGridViewTextBoxColumn.DataPropertyName = "BIENSO";
            this.bIENSODataGridViewTextBoxColumn.HeaderText = "BIENSO";
            this.bIENSODataGridViewTextBoxColumn.Name = "bIENSODataGridViewTextBoxColumn";
            this.bIENSODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lOAIXEDataGridViewTextBoxColumn
            // 
            this.lOAIXEDataGridViewTextBoxColumn.DataPropertyName = "LOAIXE";
            this.lOAIXEDataGridViewTextBoxColumn.HeaderText = "LOAIXE";
            this.lOAIXEDataGridViewTextBoxColumn.Name = "lOAIXEDataGridViewTextBoxColumn";
            this.lOAIXEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dIACHIBAIXEDataGridViewTextBoxColumn
            // 
            this.dIACHIBAIXEDataGridViewTextBoxColumn.DataPropertyName = "DIACHIBAIXE";
            this.dIACHIBAIXEDataGridViewTextBoxColumn.HeaderText = "DIACHIBAIXE";
            this.dIACHIBAIXEDataGridViewTextBoxColumn.Name = "dIACHIBAIXEDataGridViewTextBoxColumn";
            this.dIACHIBAIXEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tINHTRANGDataGridViewTextBoxColumn
            // 
            this.tINHTRANGDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.tINHTRANGDataGridViewTextBoxColumn.DataPropertyName = "TINHTRANG";
            this.tINHTRANGDataGridViewTextBoxColumn.HeaderText = "TINHTRANG";
            this.tINHTRANGDataGridViewTextBoxColumn.Name = "tINHTRANGDataGridViewTextBoxColumn";
            this.tINHTRANGDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(62, 23);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // frmQuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 550);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmQuanLy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Thuê Xe";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmQuanLy_FormClosing);
            this.Load += new System.EventHandler(this.frmQuanLy_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLOTODataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem themToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hopDongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suaChuaBaoTriToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv;
        private QLOTODataSet qLOTODataSet;
        private System.Windows.Forms.BindingSource xEBindingSource;
        private QLOTODataSetTableAdapters.XETableAdapter xETableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn mASOXEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nHANHIEUDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tENXEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bIENSODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lOAIXEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dIACHIBAIXEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tINHTRANGDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
    }
}