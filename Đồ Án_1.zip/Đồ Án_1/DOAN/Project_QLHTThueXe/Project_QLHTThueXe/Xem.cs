﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Project_QLHTThueXe
{
    public partial class frmXem : Form
    {
        public frmXem()
        {
            InitializeComponent();
        }
        clsDataBase db = new clsDataBase();
        private void frmXem_Load(object sender, EventArgs e)
        {
            dgvHD.DataSource = db.getDataTable("HOPDONG");
        }

        private void frmXem_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel = true;
        }
        
        private void btnThanhLy_Click(object sender, EventArgs e)
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                if (MessageBox.Show("Bạn có muốn thanh lý hợp đồng không?", "THông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                   == System.Windows.Forms.DialogResult.Yes)
                {
                    conn.Open();
                    // command
                    SqlCommand cmd = new SqlCommand("sp_updateThanhToan", conn);//goi store
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@MASOPHIEU", txtMHD.Text));//gan gia tri @MASOXE
                    if (cmd.ExecuteNonQuery() > 0)
                    {

                        MessageBox.Show("Đã thanh lý hợp đồng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvHD.DataSource = db.getDataTable("HOPDONG");

                    }
                    else
                    {
                        MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể thay đổi tình trạng hợp đồng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
        int index;
        private void dgvHD_Click(object sender, EventArgs e)
        {
            index = dgvHD.CurrentRow.Index;
            txtMHD.Text = dgvHD.Rows[index].Cells[0].Value.ToString();
        }

        private void btnXoaHD_Click(object sender, EventArgs e)
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                if (MessageBox.Show("Bạn có muốn xóa không?", "THông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                   == System.Windows.Forms.DialogResult.Yes)
                {
                    conn.Open();
                    // command
                    SqlCommand cmd = new SqlCommand("sp_xoaHopDong", conn);//goi store
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@MASOPHIEU", txtMHD.Text));//gan gia tri @MASOXE
                    if (cmd.ExecuteNonQuery() > 0)
                    {

                        MessageBox.Show("Đã xóa hợp đồng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvHD.DataSource = db.getDataTable("HOPDONG");

                    }
                    else
                    {
                        MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể xóa hợp đồng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
