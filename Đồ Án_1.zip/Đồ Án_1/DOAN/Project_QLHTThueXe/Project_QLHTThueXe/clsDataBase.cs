﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    class clsDataBase
    {

        // khởi tạo đối tượng kết nối đến đường dẫn cơ sở dữ liệus
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");//(duong dan Sql)
        public DataTable getDataTable(string NameTable)
        {
            string sql = "select * from " + NameTable;//câu lệnh select cần thực hiện
            SqlCommand cmd = new SqlCommand();//Khởi tạo SqlCommand để thực thi Stored procedure
            cmd.Connection = conn;//Kết nối Command đến cơ sở dữ liệu
            cmd.CommandText = sql;//thể hiện câu truy vấn
            cmd.CommandType = CommandType.Text;//Khai báo kiểu thực thi là Thực thi thủ tục
            SqlDataAdapter da = new SqlDataAdapter(cmd);//tạo đối tượng SqlAdapter là cầu nối giữa dataset và datasource để thực hiện công việc như đọc hay cập nhật dữ liệu
            DataTable dt = new DataTable();//khởi tạo đối tượng datatable
            da.Fill(dt);// fill dữ liệu vào datatable
            return dt;
        }
    }
}
