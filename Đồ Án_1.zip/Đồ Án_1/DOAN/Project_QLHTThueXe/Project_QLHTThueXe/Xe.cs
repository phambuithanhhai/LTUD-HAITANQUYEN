﻿/*Pham Bui Thanh Hai
 MSSV: 17211TT3465*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    public partial class frmXe : Form
    {
        public frmXe()
        {
            InitializeComponent();
        }

        clsDataBase db = new clsDataBase();//khai bao class
        private void Xe_FormClosing(object sender, FormClosingEventArgs e)//thong bao thoat
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (r == DialogResult.No)
                e.Cancel = true;
        }

    
        private void txtNH_Leave(object sender, EventArgs e)//xet dieu kien nhap
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)//kiem tra nhap
                this.errorProvider1.SetError(txtNH, "Bạn phải nhập Nhãn Hiệu ");
            else
                this.errorProvider1.Clear();
        }

        private void txtXe_Leave(object sender, EventArgs e)//xet dieu kien nhap
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0) //kiem tra nhap
                this.errorProvider1.SetError(txtXe, "Bạn phải nhập Tên Xe ");
            else
                this.errorProvider1.Clear();
        }

        private void txtBienSo_Leave(object sender, EventArgs e)//xet dieu kien nhap
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0) //kiem tra nhap
                this.errorProvider1.SetError(txtBienSo, "Bạn phải nhập Biển Số ");
            else
                this.errorProvider1.Clear();
        }

        private void Xe_Load(object sender, EventArgs e)//xet dieu kien nhap
        {
            drvXe.DataSource = db.getDataTable("XE");//loang thong tin bang XE
           
        }

        private void thoatToolStripMenuItem1_Click(object sender, EventArgs e)//nút thoát
        {
            this.Close();
        }
        int index; 
        private void drvXe_Click(object sender, EventArgs e)//click add thong tin xe
        {
            index = drvXe.CurrentRow.Index;
            txtMS.Text = drvXe.Rows[index].Cells[0].Value.ToString();//add thong tin ma xe
            txtNH.Text = drvXe.Rows[index].Cells[1].Value.ToString();//add thong tin nhan hieu
            txtXe.Text = drvXe.Rows[index].Cells[2].Value.ToString();//add thong tin ten xe
            txtBienSo.Text = drvXe.Rows[index].Cells[3].Value.ToString();//add thong tin bien so
            txtLX.Text = drvXe.Rows[index].Cells[4].Value.ToString();//add thong tin loai xe
            cbBX.Text = drvXe.Rows[index].Cells[5].Value.ToString();//add thong tin bai xe
        }

      

 
        private void cnTimKiem_SelectedIndexChanged(object sender, EventArgs e) //tim kiem xe theo dia chi bai xe
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_timkiemXe", conn);//store tim kiem
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@DIACHIBAIXE", cnTimKiem.Text));//gan gia tri dia chi
                // sqldataAdapter
                SqlDataAdapter daXe = new SqlDataAdapter(cmd);//tạo đối tượng SqlAdapter là cầu nối giữa dataset và datasource để thực hiện công việc như đọc hay cập nhật dữ liệu
                DataTable dtXe = new DataTable();//khởi tạo đối tượng datatable
                daXe.Fill(dtXe);// fill dữ liệu vào datatable
                drvXe.DataSource = dtXe;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }


        private void thêmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                if (txtMS.Text == "" || txtNH.Text == "" || txtXe.Text == "" || txtBienSo.Text == "" ||
                  txtLX.Text == "")
                {

                    MessageBox.Show("Thông tin chưa đầy đủ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    conn.Open();
                    // command
                    SqlCommand cmd = new SqlCommand("sp_themXe", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));//gan gia tri @MASOXE
                    cmd.Parameters.Add(new SqlParameter("@NHANHIEU", txtNH.Text));//gan gia tri @NHANHIEU
                    cmd.Parameters.Add(new SqlParameter("@TENXE", txtXe.Text));//gan gia tri @TENXE
                    cmd.Parameters.Add(new SqlParameter("@BIENSO", txtBienSo.Text));//gan gia tri @BIENSO
                    cmd.Parameters.Add(new SqlParameter("@LOAIXE", txtLX.Text));//gan gia tri @LOAIXE
                    cmd.Parameters.Add(new SqlParameter("@DIACHIBAIXE", cbBX.Text));//gan gia tri @DIACHIBAIXE
                    cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "NO"));//gan gia tri @TINHTRANG
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Thêm thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        drvXe.DataSource = db.getDataTable("XE");
                    }
                    else
                    {
                        MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Trùng Mã Số Xe không thể thêm", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }

        private void xóaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                if (MessageBox.Show("Bạn có muốn xóa không?", "THông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                   == System.Windows.Forms.DialogResult.Yes)
                {
                    conn.Open();
                    // command
                    SqlCommand cmd = new SqlCommand("sp_xoaXe", conn);//goi store
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));//gan gia tri @MASOXE
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Xóa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        drvXe.DataSource = db.getDataTable("XE");//load thong tin bang XE
                    }
                    else
                    {
                        MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Xe đang được thuê hoặc sửa chữa!Không thể xóa xe", "Thông báo");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void sửaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_updateXe", conn);//gọi store
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));//gan gia tri @MASOXE
                cmd.Parameters.Add(new SqlParameter("@NHANHIEU", txtNH.Text));//gan gia tri @NHANHIEU
                cmd.Parameters.Add(new SqlParameter("@TENXE", txtXe.Text));//gan gia tri @TENXE
                cmd.Parameters.Add(new SqlParameter("@BIENSO", txtBienSo.Text));//gan gia tri @BIENSO
                cmd.Parameters.Add(new SqlParameter("@LOAIXE", txtLX.Text));//gan gia tri @LOAIXE
                cmd.Parameters.Add(new SqlParameter("@DIACHIBAIXE", cbBX.Text));//gan gia tri @DIACHIBAIXE
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "NO"));//gan gia tri @TINHTRANG
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Sửa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    drvXe.DataSource = db.getDataTable("XE");//load thong tin bang xe
                }
                else
                {
                    MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
            }
            finally
            {
                conn.Close();
            }
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }



     

    }
        }

   
     
       

       
  
       
   
