﻿namespace Project_QLHTThueXe
{
    partial class frmQuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Khách hàng thuê xe lẻ");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Khách hàng thuê xe tháng");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Thời hạn");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Trạng thái ");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Danh mục xe");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Xuất xứ");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Hình thức thanh toán");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Thời hạn xe");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Danh mục dùng chung", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Nhà cung cấp");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Nội dung sửa chữa");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Vật tư");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Thông tin sửa chữa", new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode11,
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Danh Mục", new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode13});
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Quản Lý Kinh Doanh Xe");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Sửa Chữa - Bảo Dưỡng");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Báo Cáo");
            this.label1 = new System.Windows.Forms.Label();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.themToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hopDongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suaChuaBaoTriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gioiThieuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(302, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 31);
            this.label1.TabIndex = 18;
            this.label1.Text = "Quản Lý Hệ Thống Thuê Xe";
            // 
            // treeView1
            // 
            this.treeView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.treeView1.LabelEdit = true;
            this.treeView1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.treeView1.Location = new System.Drawing.Point(24, 95);
            this.treeView1.Name = "treeView1";
            treeNode1.ImageIndex = 6;
            treeNode1.Name = "Node4";
            treeNode1.Text = "Khách hàng thuê xe lẻ";
            treeNode2.ImageIndex = 6;
            treeNode2.Name = "Node5";
            treeNode2.Text = "Khách hàng thuê xe tháng";
            treeNode3.ImageIndex = 6;
            treeNode3.Name = "Node8";
            treeNode3.Text = "Thời hạn";
            treeNode4.ImageIndex = 6;
            treeNode4.Name = "Node9";
            treeNode4.Text = "Trạng thái ";
            treeNode5.ImageIndex = 6;
            treeNode5.Name = "Node10";
            treeNode5.Text = "Danh mục xe";
            treeNode6.ImageIndex = 6;
            treeNode6.Name = "Node11";
            treeNode6.Text = "Xuất xứ";
            treeNode7.ImageIndex = 6;
            treeNode7.Name = "Node12";
            treeNode7.Text = "Hình thức thanh toán";
            treeNode8.ImageIndex = 6;
            treeNode8.Name = "Node13";
            treeNode8.Text = "Thời hạn xe";
            treeNode9.ImageIndex = 3;
            treeNode9.Name = "nDanhMucDungChung";
            treeNode9.Text = "Danh mục dùng chung";
            treeNode10.ImageIndex = 6;
            treeNode10.Name = "Node0";
            treeNode10.Text = "Nhà cung cấp";
            treeNode11.ImageIndex = 6;
            treeNode11.Name = "Node2";
            treeNode11.Text = "Nội dung sửa chữa";
            treeNode12.ImageIndex = 6;
            treeNode12.Name = "Node3";
            treeNode12.Text = "Vật tư";
            treeNode13.ImageKey = "file-manager.jpg";
            treeNode13.Name = "nThongTinSuaChua";
            treeNode13.Text = "Thông tin sửa chữa";
            treeNode14.Name = "nDanhMuc";
            treeNode14.Text = "Danh Mục";
            treeNode15.Name = "Node0";
            treeNode15.Text = "Quản Lý Kinh Doanh Xe";
            treeNode16.Name = "Node1";
            treeNode16.Text = "Sửa Chữa - Bảo Dưỡng";
            treeNode17.Name = "Node2";
            treeNode17.Text = "Báo Cáo";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode14,
            treeNode15,
            treeNode16,
            treeNode17});
            this.treeView1.ShowPlusMinus = false;
            this.treeView1.Size = new System.Drawing.Size(321, 441);
            this.treeView1.TabIndex = 16;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem8,
            this.themToolStripMenuItem,
            this.gioiThieuToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
            this.menuStrip2.Size = new System.Drawing.Size(959, 29);
            this.menuStrip2.TabIndex = 19;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(95, 23);
            this.toolStripMenuItem8.Text = "Thông Tin";
            // 
            // themToolStripMenuItem
            // 
            this.themToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hopDongToolStripMenuItem,
            this.xeToolStripMenuItem,
            this.suaChuaBaoTriToolStripMenuItem});
            this.themToolStripMenuItem.Name = "themToolStripMenuItem";
            this.themToolStripMenuItem.Size = new System.Drawing.Size(94, 23);
            this.themToolStripMenuItem.Text = "Thêm mới";
            // 
            // hopDongToolStripMenuItem
            // 
            this.hopDongToolStripMenuItem.Name = "hopDongToolStripMenuItem";
            this.hopDongToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.hopDongToolStripMenuItem.Text = "Hợp Đồng";
            this.hopDongToolStripMenuItem.Click += new System.EventHandler(this.hopDongToolStripMenuItem_Click);
            // 
            // xeToolStripMenuItem
            // 
            this.xeToolStripMenuItem.Name = "xeToolStripMenuItem";
            this.xeToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.xeToolStripMenuItem.Text = "Xe";
            this.xeToolStripMenuItem.Click += new System.EventHandler(this.xeToolStripMenuItem_Click);
            // 
            // suaChuaBaoTriToolStripMenuItem
            // 
            this.suaChuaBaoTriToolStripMenuItem.Name = "suaChuaBaoTriToolStripMenuItem";
            this.suaChuaBaoTriToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.suaChuaBaoTriToolStripMenuItem.Text = "Sửa Chữa - Bảo Trì";
            this.suaChuaBaoTriToolStripMenuItem.Click += new System.EventHandler(this.suaChuaBaoTriToolStripMenuItem_Click);
            // 
            // gioiThieuToolStripMenuItem
            // 
            this.gioiThieuToolStripMenuItem.Name = "gioiThieuToolStripMenuItem";
            this.gioiThieuToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.gioiThieuToolStripMenuItem.Text = "Giới thiệu";
            this.gioiThieuToolStripMenuItem.Click += new System.EventHandler(this.gioiThieuToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(353, 95);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(595, 441);
            this.dataGridView1.TabIndex = 20;
            // 
            // frmQuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 550);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.treeView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmQuanLy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Thuê Xe";
            this.Load += new System.EventHandler(this.frmQuanLy_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem themToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hopDongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suaChuaBaoTriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gioiThieuToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}