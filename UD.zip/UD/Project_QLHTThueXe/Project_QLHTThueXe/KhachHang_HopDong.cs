﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    public partial class frmHopDong : Form
    {
        public frmHopDong()
        {
            InitializeComponent();
        }

        private void frmHopDong_FormClosing(object sender, FormClosingEventArgs e)
        {
           if( MessageBox.Show("Bạn có muốn thoát không?","Thông báo",MessageBoxButtons.YesNo,MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel =true;
        }
        private void thoatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSP_TextChanged(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtSP, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();

        }

        private void txtSoHD_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtSoHD, "Bạn phãi nhập Số HD");
            else
                this.errorProvider1.Clear();
        }

        private void txtTen_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtTen, "Bạn phải nhập Tên KH");
            else
                this.errorProvider1.Clear();
        }

        private void txtMSThue_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtMSThue, "Bạn phải nhập Mã Số Thuế");
            else
                this.errorProvider1.Clear();
        }

        private void txtDiaChi_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtDiaChi, "Bạn phải nhập Địa chỉ");
            else
                this.errorProvider1.Clear();
        }

        private void txtSDT_TextChanged(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtSDT, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }

        private void txtNgheNghiep_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNgheNghiep, "Bạn phải nhập Nghề Nghiệp");
            else
                this.errorProvider1.Clear();
        }

        private void txtCMND_TextChanged(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtCMND, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }
        private void txtGPLX_TextChanged(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtGPLX, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }

        private void txtNoiCapCMND_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNoiCapCMND, "Bạn phải nhập Nơi Cấp CMND");
            else
                this.errorProvider1.Clear();
        }

        private void txtNoiCapGPLX_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNoiCapGPLX, "Bạn phải nhập Nơi Cấp");
            else
                this.errorProvider1.Clear();
        }
        clsDataBase db = new clsDataBase();
        private void frmHopDong_Load(object sender, EventArgs e)//load bang
        {
            dgvXe.DataSource = db.getDataTable("XE");
            dgvKH_HD.DataSource = db.getDataTable("KHACHHANG");
        }
        
        int index;
        private void txtLocHD_TextChanged(object sender, EventArgs e) //tim hop dong theo so hop dong
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_timKiemHD", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@SOHOPDONG", txtLocHD.Text));
                // sqldataAdapter
                SqlDataAdapter daHD = new SqlDataAdapter(cmd);
                DataTable dtHD = new DataTable();
                daHD.Fill(dtHD);
                dgvKH_HD.DataSource = dtHD;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void txtLocKH_TextChanged(object sender, EventArgs e) ///tim khang hang theo ma khach hang
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_timKiemKH", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG ", txtLocKH.Text));
                // sqldataAdapter
                SqlDataAdapter daKH = new SqlDataAdapter(cmd);
                DataTable dtKH = new DataTable();
                daKH.Fill(dtKH);
                dgvKH_HD.DataSource = dtKH;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void dgvKH_HD_Click(object sender, EventArgs e) //click add thong tin khach hang
        {
            index = dgvKH_HD.CurrentRow.Index;
            txtMAKH.Text = dgvKH_HD.Rows[index].Cells[0].Value.ToString();
            txtTen.Text = dgvKH_HD.Rows[index].Cells[1].Value.ToString();
            txtDiaChi.Text = dgvKH_HD.Rows[index].Cells[2].Value.ToString();
            txtSDT.Text = dgvKH_HD.Rows[index].Cells[3].Value.ToString();
            txtCMND.Text = dgvKH_HD.Rows[index].Cells[4].Value.ToString();
            dateNgayCapCMND.Text = dgvKH_HD.Rows[index].Cells[5].Value.ToString();
            txtNoiCapCMND.Text = dgvKH_HD.Rows[index].Cells[6].Value.ToString();
            txtGPLX.Text = dgvKH_HD.Rows[index].Cells[7].Value.ToString();
            dateNoiCapGPLX.Text = dgvKH_HD.Rows[index].Cells[8].Value.ToString();
            txtNoiCapGPLX.Text = dgvKH_HD.Rows[index].Cells[9].Value.ToString();
            txtNgheNghiep.Text = dgvKH_HD.Rows[index].Cells[10].Value.ToString();
        }

        private void sửaToolStripMenuItem_Click(object sender, EventArgs e) //sua thay doi
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_updateKhachHang", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG", txtMAKH.Text));
                cmd.Parameters.Add(new SqlParameter("@HOTEN ", txtTen.Text));
                cmd.Parameters.Add(new SqlParameter("@DIACHI", txtDiaChi.Text));
                cmd.Parameters.Add(new SqlParameter("@STD", txtSDT.Text));
                cmd.Parameters.Add(new SqlParameter("@CMND", txtCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYCAPCMND", dateNgayCapCMND.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NOICAPCMND ", txtNoiCapCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@SOGPLX ", txtGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYCAPGPLX ", dateNoiCapGPLX.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NOICAPGPLX ", txtNoiCapGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NGHENGHIEP ", txtNgheNghiep.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Sua thanh cong");
                    dgvKH_HD.DataSource = db.getDataTable("KHACHHANG");
                }
                else
                {
                    MessageBox.Show("Khong thanh cong");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                //MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void kLưuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmXem x = new frmXem();
            x.Show();
        }

        private void thêmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            themKH();
            themHopDong();
         
        }
        
        public void themHopDong() /// them hop dong
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themHopdong", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOPHIEU", txtSP.Text));
                cmd.Parameters.Add(new SqlParameter("@SOHOPDONG ", txtSoHD.Text));
                cmd.Parameters.Add(new SqlParameter("@LOAIHINH", cbLH.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYTHUE ", dateNgayThue.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NGAYTRA", dateNgayTra.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NGAYKYHOPDONG", dateNgayKiHD.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@MASOTHUE ", txtMSThue.Text));
                cmd.Parameters.Add(new SqlParameter("@THANHTIEN ", txtTT.Text));
                cmd.Parameters.Add(new SqlParameter("@GHICHU ", rtGhiChu.Text));
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG ", txtMAKH.Text));
                cmd.Parameters.Add(new SqlParameter("@txtMS", txtMS.Text));
                cmd.Parameters.Add(new SqlParameter("@TRANGTHAI",""));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Them thanh cong");
                }
                else
                {
                    MessageBox.Show("Khong thanh cong");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                //MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
        public void themKH() //them khach hang
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themKH", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG", txtMAKH.Text));
                cmd.Parameters.Add(new SqlParameter("@HOTEN ", txtTen.Text));
                cmd.Parameters.Add(new SqlParameter("@DIACHI", txtDiaChi.Text));
                cmd.Parameters.Add(new SqlParameter("@STD", txtSDT.Text));
                cmd.Parameters.Add(new SqlParameter("@CMND", txtCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYCAPCMND", dateNgayCapCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@NOICAPCMND ", txtNoiCapCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@SOGPLX ", txtGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYCAPGPLX ", dateNoiCapGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NOICAPGPLX ", txtNoiCapGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NGHENGHIEP ", txtNgheNghiep.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                   dgvKH_HD.DataSource = db.getDataTable("KHACHHANG");
                }
                else
                {
                    MessageBox.Show("Khong thanh cong");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                //MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void dgvXe_Click(object sender, EventArgs e) //click vào add Maxe
        {
            index = dgvXe.CurrentRow.Index;
            txtMS.Text = dgvXe.Rows[index].Cells[0].Value.ToString();
        }

      

       

        

       

        
      
    



      

      

      

     


   

       


      

      

    }
}
