﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
namespace Project_QLHTThueXe
{
    public partial class frmDangNhap : Form
    {
        //goi class ket noi csdl
        clsDataBase db = new clsDataBase();

        public frmDangNhap()
        {
            InitializeComponent();
        }

        //xet dieu kien nhap txtTaiKhoan
        private void txtTaiKhoan_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)//neu de trong
                this.errorProvider1.SetError(txtTaiKhoan, "You must enter Account");//thong bao de nhap
            else
                this.errorProvider1.Clear();//

        }
        //Thong bao thoat
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r;
            r = MessageBox.Show("Do you want to close?", "Exit",
                MessageBoxButtons.YesNo,//nut yes va no
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button1);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
        //nut thoat
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //nut dang nhap
       private void btnDangNhap_Click(object sender, EventArgs e)//kiem tra dang nhap
        {
           // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");//(duong dan sql)
            
            try
            {
                conn.Open();// mo ket noi
                // command
                SqlCommand cmd = new SqlCommand("sp_DangNhap", conn); //goi storeproduce Dang nhap
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@USERNAME", txtTaiKhoan.Text));//(bien taikhoan trong Sql = gia tri txtTaiKhoan Nhap)
                cmd.Parameters.Add(new SqlParameter("@MATKHAU", txtPass.Text));//bien matkhau trong Sql = gtri txtPass nhap
                int x = (int)cmd.ExecuteScalar();//ktra gia tri
                if (x > 0)//Ktra ton tai 
                {
                    MessageBox.Show("Dang nhap thanh cong");//thong bao thanh cong khi dung
                    this.Close();//thoat khoi form Dang Nhap
                    frmQuanLy ql = new frmQuanLy();//goi qua from Quan Ly
                    ql.Show();//Hien from Quan Ly
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Tài khoản hoặc mật khẩu sai", "Thông Báo");//Thong bao sai
            }
            finally
            {
                conn.Close();//dong ket noi
            }
        }

       private void frmDangNhap_Load(object sender, EventArgs e)
       {

       }    
    }
}
