﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project_QLHTThueXe
{
    public partial class frmQuanLy : Form
    {
        public frmQuanLy()
        {
            InitializeComponent();
        }

        private void hopDongToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHopDong hd = new frmHopDong();//Khởi tạo form Hợp đồng
            hd.Show();//Show formHop Đồng
        }

        private void xeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmXe xe = new frmXe();//Khời tạo form Xe
            xe.Show();//show form
        }

        private void suaChuaBaoTriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuaChua sc = new frmSuaChua();//Khởi tạo form Sua chua bao trì 
            sc.Show();//Show form
        }

        private void gioiThieuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string kq = "";
            kq += "Phần mềm quản lí cho thuê xe ô tô\n";
            kq += "Website: Congtyphanmem.com\n";
            kq += "Design: Congtyphanmem\n";
            kq += "SDT: 0123456789\n";
            kq += "Địa chỉ: 23 Võ Văn Ngân, Phường Linh Chiểu, Quận Thủ Đức, Tp. Hồ Chí Minh";

            MessageBox.Show(kq, "Thông tin");
        }

        private void frmQuanLy_Load(object sender, EventArgs e)
        {

        }


        private void xeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmXe xe = new frmXe();//Khời tạo form Xe
            xe.WindowState = FormWindowState.Maximized;
            xe.MdiParent = this;
            xe.Show();//show form
        }

        private void hợpĐồngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHopDong hd = new frmHopDong();//Khởi tạo form Hợp đồng
            hd.WindowState = FormWindowState.Maximized;
            hd.MdiParent = this;
            hd.Show();//Show formHop Đồng
        }

        private void sửaChửaBảoTrìToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuaChua sc = new frmSuaChua();//Khởi tạo form Sua chua bao trì 
            sc.WindowState = FormWindowState.Maximized;
            sc.MdiParent = this;
            sc.Show();//Show form
        }

        private void đăngNhậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDangNhap dn2 = new frmDangNhap();
            dn2.MdiParent = this;
            dn2.Show();        
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

       

       
    }
}
