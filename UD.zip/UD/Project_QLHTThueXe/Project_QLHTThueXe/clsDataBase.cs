﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    class clsDataBase 
    {
        //ket noi csdl
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");//(duong dan Sql)
        
        public DataTable getDataTable(string NameTable)
        {

            string sql = "select * from " + NameTable;//lay tu bang..
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}
