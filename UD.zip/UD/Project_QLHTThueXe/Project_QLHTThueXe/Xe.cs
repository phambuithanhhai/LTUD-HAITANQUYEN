﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    public partial class frmXe : Form
    {
        public frmXe()
        {
            InitializeComponent();
        }

        clsDataBase db = new clsDataBase();//khoi tao class database
        private void Xe_FormClosing(object sender, FormClosingEventArgs e)//tao button thoat
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);//hien thi thong bao thoat
            if (r == DialogResult.No)
                e.Cancel = true;
        }

        private void btnThoat_Click(object sender, EventArgs e)//tao button thoat trong chuong trinh
        {
            this.Close();// dong chuong trinh
        }
     
        /*
        private void txtNH_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNH, "Bạn phải nhập Nhãn Hiệu ");
            else
                this.errorProvider1.Clear();
        }

        private void txtXe_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtXe, "Bạn phải nhập Tên Xe ");
            else
                this.errorProvider1.Clear();
        }

        private void txtBienSo_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtBienSo, "Bạn phải nhập Biển Số ");
            else
                this.errorProvider1.Clear();
        }
        */
 


        private void Xe_Load(object sender, EventArgs e)//load bang xe
        {
            drvXe.DataSource = db.getDataTable("XE");//hien thi len datarv
           
        }

        private void thoatToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLuu_Click(object sender, EventArgs e) ///sua thong tin xe
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_updateXe", conn);// goi store upfate xe
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));
                cmd.Parameters.Add(new SqlParameter("@NHANHIEU", txtNH.Text));
                cmd.Parameters.Add(new SqlParameter("@TENXE", txtXe.Text));
                cmd.Parameters.Add(new SqlParameter("@BIENSO", txtBienSo.Text));
                cmd.Parameters.Add(new SqlParameter("@LOAIXE", txtLX.Text));
                cmd.Parameters.Add(new SqlParameter("@DIACHIBAIXE", cbBX.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "NO"));
                if (cmd.ExecuteNonQuery() > 0)//kiem tra gia tri co ton tai 
                {
                MessageBox.Show("Sua thanh cong");
                drvXe.DataSource = db.getDataTable("XE");// cap nhat lai
                }
                else
                {
                    MessageBox.Show("Khong thanh cong");
                }


            }
            catch (Exception ex)//nhap sai bai loi
            {
                MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                //MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

       
        private void btnXoa_Click(object sender, EventArgs e)//xoa xe
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_xoaXe", conn);//goi store xoa xe
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));//nhap vao ma xe can xoa
                if (cmd.ExecuteNonQuery() > 0)// kiem tr gia tri co ton tai
                {
                    MessageBox.Show("Xóa thành công");// thong bao xoa thanh cobng
                    drvXe.DataSource = db.getDataTable("XE");//Update du lieu
                }
                else
                {
                    MessageBox.Show("Không thành công");
                }


            }
            catch (Exception ex)//nhap sai bao loi
            {
                //MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                MessageBox.Show("Xe đang được thuê hoặc sửa chữa!Không thể xóa xe", "Thông báo");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
        int index; //hien thi len drv
        private void drvXe_Click(object sender, EventArgs e)//click add thong tin xe
        {
            index = drvXe.CurrentRow.Index;
            txtMS.Text = drvXe.Rows[index].Cells[0].Value.ToString();//hien thi len drvtheo tung cot
            txtNH.Text = drvXe.Rows[index].Cells[1].Value.ToString();
            txtXe.Text = drvXe.Rows[index].Cells[2].Value.ToString();
            txtBienSo.Text = drvXe.Rows[index].Cells[3].Value.ToString();
            txtLX.Text = drvXe.Rows[index].Cells[4].Value.ToString();
            cbBX.Text = drvXe.Rows[index].Cells[5].Value.ToString();
        }

        private void btnThem_Click(object sender, EventArgs e)//them xe
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themXe", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));
                cmd.Parameters.Add(new SqlParameter("@NHANHIEU", txtNH.Text));
                cmd.Parameters.Add(new SqlParameter("@TENXE", txtXe.Text));
                cmd.Parameters.Add(new SqlParameter("@BIENSO", txtBienSo.Text));
                cmd.Parameters.Add(new SqlParameter("@LOAIXE", txtLX.Text));
                cmd.Parameters.Add(new SqlParameter("@DIACHIBAIXE", cbBX.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "NO"));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Them thanh cong");
                    drvXe.DataSource = db.getDataTable("XE");
                }
                else
                {
                    MessageBox.Show("Khong thanh cong");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Trùng Mã Số Xe", "Thông Báo");
            }
            finally
            {
                conn.Close();
            }
        }

 
        private void cnTimKiem_SelectedIndexChanged(object sender, EventArgs e) //tim kiem xe theo dia chi bai xe combobox
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_timkiemXe", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@DIACHIBAIXE", cnTimKiem.Text));
                // sqldataAdapter
               SqlDataAdapter daXe = new SqlDataAdapter(cmd);
                DataTable dtXe = new DataTable();
                daXe.Fill(dtXe);
                drvXe.DataSource = dtXe;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
    }
        }

   
     
       

       
  
       
   
