﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project_QLHTThueXe
{
    public partial class frmXem : Form
    {
        public frmXem()
        {
            InitializeComponent();
        }
        clsDataBase db = new clsDataBase();
        private void frmXem_Load(object sender, EventArgs e)
        {
            dgvHD.DataSource = db.getDataTable("HOPDONG");
        }
    }
}
