﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
namespace Project_QLHTThueXe
{
    public partial class frmSuaChua : Form
    {
        public frmSuaChua()
        {
            InitializeComponent();
        }
        clsDataBase db = new clsDataBase();
        private void SuaChua_BaoTri_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel = true;
        }

        private void txtMhd_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
            {
                this.errorProvider1.SetError(txtMhd, "You must enter Your Mhd");

            }
            else
                this.errorProvider1.Clear();
        }

        private void txtNcc_Leave(object sender, EventArgs e)
        {
             Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length == 0 )
                {
                    this.errorProvider1.SetError(txtNcc, "You must enter your nha cung cap");

                }
                else
                    this.errorProvider1.Clear();
           
           
        }

        private void txtMs_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtMs, "You must enter your number");
            else
                this.errorProvider1.Clear();
        }

        private void txtNd_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNd, "You must enter your text");
            else
                this.errorProvider1.Clear();
        }

        private void txtTt_Leave(object sender, EventArgs e)
        {
                        Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtTt, "This is not invalid number");
            else
                this.errorProvider1.Clear();


        }

        private void thoa1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------//
        
        private void frmSuaChua_Load(object sender, EventArgs e)//load thong tin
        {
            drvSC.DataSource = db.getDataTable("SUACHUABAOTRI");
            drvXe.DataSource= db.getDataTable( "XE");
            
        }

        private void btnThem_Click(object sender, EventArgs e)//them sua chua
        {

            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themSuaChua", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAHOADON", txtMhd.Text));
                cmd.Parameters.Add(new SqlParameter("@NHACUNGCAP", txtNcc.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYSUACHUA", dateSc.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NGAYHOANTAT", dateHt.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@MASOXE",txtMs.Text));
                cmd.Parameters.Add(new SqlParameter("@NOIDUNGCHITIET", txtNd.Text));
                cmd.Parameters.Add(new SqlParameter("@TONGTIEN", txtTt.Text));
                cmd.Parameters.Add(new SqlParameter("@THANHTOAN", cbThanhToan.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Them thanh cong");
                    drvSC.DataSource = db.getDataTable("SUACHUABAOTRI");
                    updateTinhTrang();
                    drvXe.DataSource = db.getDataTable("XE");
                   
                }
                else
                {
                    MessageBox.Show("Khong thanh cong");
                }


            }
            catch (Exception ex)
            {
                //MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");// thong bao loi
                MessageBox.Show("Loi ket noi " + ex.Message, "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

             int index;
             private void drvSC_Click(object sender, EventArgs e)//click add thong tin
             {
                 index = drvSC.CurrentRow.Index;
                 txtMhd.Text = drvSC.Rows[index].Cells[0].Value.ToString();
                 txtNcc.Text = drvSC.Rows[index].Cells[1].Value.ToString();
                 dateSc.Text = drvSC.Rows[index].Cells[2].Value.ToString();
                 dateHt.Text = drvSC.Rows[index].Cells[3].Value.ToString();
                 txtMs.Text = drvSC.Rows[index].Cells[4].Value.ToString();
                 txtNd.Text = drvSC.Rows[index].Cells[5].Value.ToString();
                 txtTt.Text = drvSC.Rows[index].Cells[6].Value.ToString();
                 cbThanhToan.Text = drvSC.Rows[index].Cells[7].Value.ToString();
             
             }

             private void dgvXe_Click(object sender, EventArgs e)//click add ma so xe
             {
                 index = drvXe.CurrentRow.Index;
                 txtMs.Text = drvXe.Rows[index].Cells[0].Value.ToString();
                 
             }
 

             public void updateTinhTrang()//thay doi tinh trang xe YES khi xe duoc sua chua
             {
                 // ket noi db
                 SqlConnection conn = new SqlConnection("Data Source=DESKTOP-13RCLR9;Initial Catalog=QLOTO;Integrated Security=True");
                 // mo ket noi
                 try
                 {
                     conn.Open();
                     // command
                     SqlCommand cmd = new SqlCommand("sp_updateTinhTrang", conn);
                     cmd.CommandType = CommandType.StoredProcedure;
                     cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMs.Text));
                     cmd.Parameters.Add(new SqlParameter("@TINHTRANG","YES"));
                     if (cmd.ExecuteNonQuery() > 0)
                     {
                         drvSC.DataSource = db.getDataTable("XE");
                     }
                     else
                     {
                         MessageBox.Show("Khong thanh cong");
                     }
                 }
                 catch (Exception ex)
                 {
                     //MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã Số Xe", "Thông Báo");
                     MessageBox.Show("Loi ket noi aaa" + ex.Message, "Thong bao");// thong bao loi
                 }
                 finally
                 {
                     conn.Close();
                 }
             } 
    }
}
