﻿namespace Project_QLHTThueXe
{
    partial class frmHopDong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thêmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmKháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmHợpĐồngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemDanhSáchKháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.grpHopDong = new System.Windows.Forms.GroupBox();
            this.txtMS = new System.Windows.Forms.TextBox();
            this.cbLH = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dateNgayKiHD = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.dateNgayTra = new System.Windows.Forms.DateTimePicker();
            this.dateNgayThue = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSoHD = new System.Windows.Forms.TextBox();
            this.txtMSThue = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtSP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grpKhachHang = new System.Windows.Forms.GroupBox();
            this.txtMAKH = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtNgheNghiep = new System.Windows.Forms.TextBox();
            this.txtNoiCapCMND = new System.Windows.Forms.TextBox();
            this.txtNoiCapGPLX = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.dateNoiCapGPLX = new System.Windows.Forms.DateTimePicker();
            this.dateNgayCapCMND = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtGPLX = new System.Windows.Forms.TextBox();
            this.txtCMND = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dsadasd = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.grpXe = new System.Windows.Forms.GroupBox();
            this.dgvXe = new System.Windows.Forms.DataGridView();
            this.label20 = new System.Windows.Forms.Label();
            this.rtGhiChu = new System.Windows.Forms.RichTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtVAT = new System.Windows.Forms.TextBox();
            this.txtTT = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtLocHD = new System.Windows.Forms.TextBox();
            this.txtLocKH = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.dgvKH_HD = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            this.grpHopDong.SuspendLayout();
            this.grpKhachHang.SuspendLayout();
            this.grpXe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKH_HD)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thêmToolStripMenuItem,
            this.sửaToolStripMenuItem,
            this.xemToolStripMenuItem,
            this.xóaToolStripMenuItem,
            this.thoatToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(967, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thêmToolStripMenuItem
            // 
            this.thêmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thêmKháchHàngToolStripMenuItem,
            this.thêmHợpĐồngToolStripMenuItem});
            this.thêmToolStripMenuItem.Name = "thêmToolStripMenuItem";
            this.thêmToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.thêmToolStripMenuItem.Text = "Thêm";
            // 
            // thêmKháchHàngToolStripMenuItem
            // 
            this.thêmKháchHàngToolStripMenuItem.Name = "thêmKháchHàngToolStripMenuItem";
            this.thêmKháchHàngToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.thêmKháchHàngToolStripMenuItem.Text = "Thêm khách hàng";
            this.thêmKháchHàngToolStripMenuItem.Click += new System.EventHandler(this.thêmKháchHàngToolStripMenuItem_Click);
            // 
            // thêmHợpĐồngToolStripMenuItem
            // 
            this.thêmHợpĐồngToolStripMenuItem.Name = "thêmHợpĐồngToolStripMenuItem";
            this.thêmHợpĐồngToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.thêmHợpĐồngToolStripMenuItem.Text = "Thêm hợp đồng";
            this.thêmHợpĐồngToolStripMenuItem.Click += new System.EventHandler(this.thêmHợpĐồngToolStripMenuItem_Click);
            // 
            // sửaToolStripMenuItem
            // 
            this.sửaToolStripMenuItem.Name = "sửaToolStripMenuItem";
            this.sửaToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sửaToolStripMenuItem.Text = "Sửa";
            this.sửaToolStripMenuItem.Click += new System.EventHandler(this.sửaToolStripMenuItem_Click);
            // 
            // xemToolStripMenuItem
            // 
            this.xemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xemDanhSáchKháchHàngToolStripMenuItem});
            this.xemToolStripMenuItem.Name = "xemToolStripMenuItem";
            this.xemToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.xemToolStripMenuItem.Text = "Xem";
            this.xemToolStripMenuItem.Click += new System.EventHandler(this.kLưuToolStripMenuItem_Click);
            // 
            // xemDanhSáchKháchHàngToolStripMenuItem
            // 
            this.xemDanhSáchKháchHàngToolStripMenuItem.Name = "xemDanhSáchKháchHàngToolStripMenuItem";
            this.xemDanhSáchKháchHàngToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.xemDanhSáchKháchHàngToolStripMenuItem.Text = "Xem danh sách khách hàng";
            // 
            // xóaToolStripMenuItem
            // 
            this.xóaToolStripMenuItem.Name = "xóaToolStripMenuItem";
            this.xóaToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.xóaToolStripMenuItem.Text = "Xóa";
            this.xóaToolStripMenuItem.Click += new System.EventHandler(this.xóaToolStripMenuItem_Click);
            // 
            // thoatToolStripMenuItem
            // 
            this.thoatToolStripMenuItem.Name = "thoatToolStripMenuItem";
            this.thoatToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.thoatToolStripMenuItem.Text = "Thoát";
            this.thoatToolStripMenuItem.Click += new System.EventHandler(this.thoatToolStripMenuItem_Click);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Số Phiếu";
            this.columnHeader2.Width = 121;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Khách Hàng";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader3.Width = 123;
            // 
            // grpHopDong
            // 
            this.grpHopDong.Controls.Add(this.txtMS);
            this.grpHopDong.Controls.Add(this.cbLH);
            this.grpHopDong.Controls.Add(this.label9);
            this.grpHopDong.Controls.Add(this.dateNgayKiHD);
            this.grpHopDong.Controls.Add(this.label8);
            this.grpHopDong.Controls.Add(this.dateNgayTra);
            this.grpHopDong.Controls.Add(this.dateNgayThue);
            this.grpHopDong.Controls.Add(this.label7);
            this.grpHopDong.Controls.Add(this.label6);
            this.grpHopDong.Controls.Add(this.txtSoHD);
            this.grpHopDong.Controls.Add(this.txtMSThue);
            this.grpHopDong.Controls.Add(this.label14);
            this.grpHopDong.Controls.Add(this.txtSP);
            this.grpHopDong.Controls.Add(this.label5);
            this.grpHopDong.Controls.Add(this.label4);
            this.grpHopDong.Controls.Add(this.label3);
            this.grpHopDong.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpHopDong.Location = new System.Drawing.Point(344, 34);
            this.grpHopDong.Name = "grpHopDong";
            this.grpHopDong.Size = new System.Drawing.Size(611, 111);
            this.grpHopDong.TabIndex = 8;
            this.grpHopDong.TabStop = false;
            this.grpHopDong.Text = "Thông Tin Hợp Đồng Cho Thuê Xe";
            // 
            // txtMS
            // 
            this.txtMS.Location = new System.Drawing.Point(330, 81);
            this.txtMS.Name = "txtMS";
            this.txtMS.Size = new System.Drawing.Size(95, 21);
            this.txtMS.TabIndex = 13;
            // 
            // cbLH
            // 
            this.cbLH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLH.FormattingEnabled = true;
            this.cbLH.Items.AddRange(new object[] {
            "Kinh Doanh",
            "Cá Nhân",
            "Du Lịch",
            "Công Ty"});
            this.cbLH.Location = new System.Drawing.Point(90, 81);
            this.cbLH.Name = "cbLH";
            this.cbLH.Size = new System.Drawing.Size(137, 21);
            this.cbLH.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(249, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Mã Số Xe:";
            // 
            // dateNgayKiHD
            // 
            this.dateNgayKiHD.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNgayKiHD.Location = new System.Drawing.Point(330, 55);
            this.dateNgayKiHD.Name = "dateNgayKiHD";
            this.dateNgayKiHD.Size = new System.Drawing.Size(95, 21);
            this.dateNgayKiHD.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(249, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Ngày Kí HĐ";
            // 
            // dateNgayTra
            // 
            this.dateNgayTra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNgayTra.Location = new System.Drawing.Point(495, 29);
            this.dateNgayTra.Name = "dateNgayTra";
            this.dateNgayTra.Size = new System.Drawing.Size(113, 21);
            this.dateNgayTra.TabIndex = 8;
            // 
            // dateNgayThue
            // 
            this.dateNgayThue.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNgayThue.Location = new System.Drawing.Point(330, 26);
            this.dateNgayThue.Name = "dateNgayThue";
            this.dateNgayThue.Size = new System.Drawing.Size(95, 21);
            this.dateNgayThue.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(431, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Ngày Trả";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(249, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ngày Thuê";
            // 
            // txtSoHD
            // 
            this.txtSoHD.Location = new System.Drawing.Point(90, 53);
            this.txtSoHD.Name = "txtSoHD";
            this.txtSoHD.Size = new System.Drawing.Size(137, 21);
            this.txtSoHD.TabIndex = 4;
            this.txtSoHD.Leave += new System.EventHandler(this.txtSoHD_Leave);
            // 
            // txtMSThue
            // 
            this.txtMSThue.Location = new System.Drawing.Point(495, 58);
            this.txtMSThue.Name = "txtMSThue";
            this.txtMSThue.Size = new System.Drawing.Size(113, 21);
            this.txtMSThue.TabIndex = 10;
            this.txtMSThue.Leave += new System.EventHandler(this.txtMSThue_Leave);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(431, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 13);
            this.label14.TabIndex = 11;
            this.label14.Text = "Mã Số Thuế";
            // 
            // txtSP
            // 
            this.txtSP.Location = new System.Drawing.Point(90, 26);
            this.txtSP.Name = "txtSP";
            this.txtSP.Size = new System.Drawing.Size(137, 21);
            this.txtSP.TabIndex = 3;
            this.txtSP.TextChanged += new System.EventHandler(this.txtSP_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Loại Hình KD";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Số Hợp Đồng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Số Phiếu";
            // 
            // grpKhachHang
            // 
            this.grpKhachHang.Controls.Add(this.txtMAKH);
            this.grpKhachHang.Controls.Add(this.label27);
            this.grpKhachHang.Controls.Add(this.txtNgheNghiep);
            this.grpKhachHang.Controls.Add(this.txtNoiCapCMND);
            this.grpKhachHang.Controls.Add(this.txtNoiCapGPLX);
            this.grpKhachHang.Controls.Add(this.label19);
            this.grpKhachHang.Controls.Add(this.label18);
            this.grpKhachHang.Controls.Add(this.label17);
            this.grpKhachHang.Controls.Add(this.dateNoiCapGPLX);
            this.grpKhachHang.Controls.Add(this.dateNgayCapCMND);
            this.grpKhachHang.Controls.Add(this.label16);
            this.grpKhachHang.Controls.Add(this.label15);
            this.grpKhachHang.Controls.Add(this.txtGPLX);
            this.grpKhachHang.Controls.Add(this.txtCMND);
            this.grpKhachHang.Controls.Add(this.txtSDT);
            this.grpKhachHang.Controls.Add(this.txtDiaChi);
            this.grpKhachHang.Controls.Add(this.label13);
            this.grpKhachHang.Controls.Add(this.label12);
            this.grpKhachHang.Controls.Add(this.dsadasd);
            this.grpKhachHang.Controls.Add(this.label11);
            this.grpKhachHang.Controls.Add(this.txtTen);
            this.grpKhachHang.Controls.Add(this.label10);
            this.grpKhachHang.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpKhachHang.Location = new System.Drawing.Point(341, 151);
            this.grpKhachHang.Name = "grpKhachHang";
            this.grpKhachHang.Size = new System.Drawing.Size(614, 189);
            this.grpKhachHang.TabIndex = 9;
            this.grpKhachHang.TabStop = false;
            this.grpKhachHang.Text = "Thông Tin Khách Hàng";
            // 
            // txtMAKH
            // 
            this.txtMAKH.Location = new System.Drawing.Point(375, 29);
            this.txtMAKH.Name = "txtMAKH";
            this.txtMAKH.Size = new System.Drawing.Size(233, 21);
            this.txtMAKH.TabIndex = 23;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(327, 32);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 13);
            this.label27.TabIndex = 22;
            this.label27.Text = "Mã KH:";
            // 
            // txtNgheNghiep
            // 
            this.txtNgheNghiep.Location = new System.Drawing.Point(310, 84);
            this.txtNgheNghiep.Name = "txtNgheNghiep";
            this.txtNgheNghiep.Size = new System.Drawing.Size(298, 21);
            this.txtNgheNghiep.TabIndex = 21;
            this.txtNgheNghiep.Leave += new System.EventHandler(this.txtNgheNghiep_Leave);
            // 
            // txtNoiCapCMND
            // 
            this.txtNoiCapCMND.Location = new System.Drawing.Point(481, 116);
            this.txtNoiCapCMND.Name = "txtNoiCapCMND";
            this.txtNoiCapCMND.Size = new System.Drawing.Size(127, 21);
            this.txtNoiCapCMND.TabIndex = 20;
            this.txtNoiCapCMND.Leave += new System.EventHandler(this.txtNoiCapCMND_Leave);
            // 
            // txtNoiCapGPLX
            // 
            this.txtNoiCapGPLX.Location = new System.Drawing.Point(481, 149);
            this.txtNoiCapGPLX.Name = "txtNoiCapGPLX";
            this.txtNoiCapGPLX.Size = new System.Drawing.Size(127, 21);
            this.txtNoiCapGPLX.TabIndex = 19;
            this.txtNoiCapGPLX.Leave += new System.EventHandler(this.txtNoiCapGPLX_Leave);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(406, 148);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 13);
            this.label19.TabIndex = 18;
            this.label19.Text = "Nơi Cấp GPLX";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(404, 120);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(76, 13);
            this.label18.TabIndex = 17;
            this.label18.Text = "Nơi Cấp CMND";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(228, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 13);
            this.label17.TabIndex = 16;
            this.label17.Text = "Nghề Nghiệp";
            // 
            // dateNoiCapGPLX
            // 
            this.dateNoiCapGPLX.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNoiCapGPLX.Location = new System.Drawing.Point(310, 144);
            this.dateNoiCapGPLX.Name = "dateNoiCapGPLX";
            this.dateNoiCapGPLX.Size = new System.Drawing.Size(93, 21);
            this.dateNoiCapGPLX.TabIndex = 15;
            // 
            // dateNgayCapCMND
            // 
            this.dateNgayCapCMND.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNgayCapCMND.Location = new System.Drawing.Point(310, 116);
            this.dateNgayCapCMND.Name = "dateNgayCapCMND";
            this.dateNgayCapCMND.Size = new System.Drawing.Size(93, 21);
            this.dateNgayCapCMND.TabIndex = 14;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(228, 120);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Ngày cấp CMND";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(228, 148);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "Ngày Cấp GPLX";
            // 
            // txtGPLX
            // 
            this.txtGPLX.Location = new System.Drawing.Point(90, 144);
            this.txtGPLX.Name = "txtGPLX";
            this.txtGPLX.Size = new System.Drawing.Size(137, 21);
            this.txtGPLX.TabIndex = 9;
            this.txtGPLX.TextChanged += new System.EventHandler(this.txtGPLX_TextChanged);
            // 
            // txtCMND
            // 
            this.txtCMND.Location = new System.Drawing.Point(90, 116);
            this.txtCMND.Name = "txtCMND";
            this.txtCMND.Size = new System.Drawing.Size(137, 21);
            this.txtCMND.TabIndex = 8;
            this.txtCMND.TextChanged += new System.EventHandler(this.txtCMND_TextChanged);
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(90, 87);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(137, 21);
            this.txtSDT.TabIndex = 7;
            this.txtSDT.TextChanged += new System.EventHandler(this.txtSDT_TextChanged);
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(90, 58);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(518, 21);
            this.txtDiaChi.TabIndex = 6;
            this.txtDiaChi.Leave += new System.EventHandler(this.txtDiaChi_Leave);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(18, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 13);
            this.label13.TabIndex = 5;
            this.label13.Text = "Điện Thoại";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 149);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Số GPLX";
            // 
            // dsadasd
            // 
            this.dsadasd.AutoSize = true;
            this.dsadasd.Location = new System.Drawing.Point(17, 121);
            this.dsadasd.Name = "dsadasd";
            this.dsadasd.Size = new System.Drawing.Size(51, 13);
            this.dsadasd.TabIndex = 3;
            this.dsadasd.Text = "Số CMND";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Địa Chỉ";
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(90, 29);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(219, 21);
            this.txtTen.TabIndex = 1;
            this.txtTen.Leave += new System.EventHandler(this.txtTen_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Tên KH";
            // 
            // grpXe
            // 
            this.grpXe.Controls.Add(this.dgvXe);
            this.grpXe.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpXe.Location = new System.Drawing.Point(341, 346);
            this.grpXe.Name = "grpXe";
            this.grpXe.Size = new System.Drawing.Size(614, 154);
            this.grpXe.TabIndex = 10;
            this.grpXe.TabStop = false;
            this.grpXe.Text = "Chi Tiết Xe";
            // 
            // dgvXe
            // 
            this.dgvXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXe.Location = new System.Drawing.Point(6, 14);
            this.dgvXe.Name = "dgvXe";
            this.dgvXe.Size = new System.Drawing.Size(614, 140);
            this.dgvXe.TabIndex = 0;
            this.dgvXe.Click += new System.EventHandler(this.dgvXe_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(338, 516);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 13);
            this.label20.TabIndex = 13;
            this.label20.Text = "Ghi Chú";
            // 
            // rtGhiChu
            // 
            this.rtGhiChu.Location = new System.Drawing.Point(398, 515);
            this.rtGhiChu.Name = "rtGhiChu";
            this.rtGhiChu.Size = new System.Drawing.Size(334, 73);
            this.rtGhiChu.TabIndex = 14;
            this.rtGhiChu.Text = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(761, 516);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(26, 13);
            this.label21.TabIndex = 15;
            this.label21.Text = "VAT";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(761, 550);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 13);
            this.label22.TabIndex = 16;
            this.label22.Text = "Thành Tiền";
            // 
            // txtVAT
            // 
            this.txtVAT.Location = new System.Drawing.Point(839, 511);
            this.txtVAT.Name = "txtVAT";
            this.txtVAT.Size = new System.Drawing.Size(43, 23);
            this.txtVAT.TabIndex = 19;
            this.txtVAT.Text = "10%";
            // 
            // txtTT
            // 
            this.txtTT.Location = new System.Drawing.Point(839, 540);
            this.txtTT.Name = "txtTT";
            this.txtTT.Size = new System.Drawing.Size(113, 23);
            this.txtTT.TabIndex = 20;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(12, 557);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(85, 13);
            this.label25.TabIndex = 23;
            this.label25.Text = "Lọc số hợp đồng";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(187, 557);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(81, 13);
            this.label26.TabIndex = 24;
            this.label26.Text = "Lọc khách hàng";
            // 
            // txtLocHD
            // 
            this.txtLocHD.Location = new System.Drawing.Point(12, 531);
            this.txtLocHD.Name = "txtLocHD";
            this.txtLocHD.Size = new System.Drawing.Size(136, 23);
            this.txtLocHD.TabIndex = 25;
            this.txtLocHD.TextChanged += new System.EventHandler(this.txtLocHD_TextChanged);
            // 
            // txtLocKH
            // 
            this.txtLocKH.Location = new System.Drawing.Point(190, 531);
            this.txtLocKH.Name = "txtLocKH";
            this.txtLocKH.Size = new System.Drawing.Size(142, 23);
            this.txtLocKH.TabIndex = 26;
            this.txtLocKH.TextChanged += new System.EventHandler(this.txtLocKH_TextChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // dgvKH_HD
            // 
            this.dgvKH_HD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKH_HD.Location = new System.Drawing.Point(12, 34);
            this.dgvKH_HD.Name = "dgvKH_HD";
            this.dgvKH_HD.Size = new System.Drawing.Size(320, 466);
            this.dgvKH_HD.TabIndex = 27;
            this.dgvKH_HD.Click += new System.EventHandler(this.dgvKH_HD_Click);
            // 
            // frmHopDong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(967, 600);
            this.ControlBox = false;
            this.Controls.Add(this.dgvKH_HD);
            this.Controls.Add(this.txtLocKH);
            this.Controls.Add(this.txtLocHD);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtTT);
            this.Controls.Add(this.txtVAT);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.rtGhiChu);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.grpXe);
            this.Controls.Add(this.grpKhachHang);
            this.Controls.Add(this.grpHopDong);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmHopDong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Hợp đồng cho thuê xe";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmHopDong_FormClosing);
            this.Load += new System.EventHandler(this.frmHopDong_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpHopDong.ResumeLayout(false);
            this.grpHopDong.PerformLayout();
            this.grpKhachHang.ResumeLayout(false);
            this.grpKhachHang.PerformLayout();
            this.grpXe.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKH_HD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sửaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpHopDong;
        private System.Windows.Forms.ComboBox cbLH;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateNgayKiHD;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dateNgayTra;
        private System.Windows.Forms.DateTimePicker dateNgayThue;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtSoHD;
        private System.Windows.Forms.TextBox txtSP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpKhachHang;
        private System.Windows.Forms.TextBox txtNgheNghiep;
        private System.Windows.Forms.TextBox txtNoiCapCMND;
        private System.Windows.Forms.TextBox txtNoiCapGPLX;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DateTimePicker dateNoiCapGPLX;
        private System.Windows.Forms.DateTimePicker dateNgayCapCMND;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtMSThue;
        private System.Windows.Forms.TextBox txtGPLX;
        private System.Windows.Forms.TextBox txtCMND;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label dsadasd;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox grpXe;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RichTextBox rtGhiChu;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtVAT;
        private System.Windows.Forms.TextBox txtTT;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtLocHD;
        private System.Windows.Forms.TextBox txtLocKH;
        private System.Windows.Forms.ToolStripMenuItem thoatToolStripMenuItem;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.DataGridView dgvXe;
        private System.Windows.Forms.DataGridView dgvKH_HD;
        private System.Windows.Forms.TextBox txtMAKH;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ToolStripMenuItem xemDanhSáchKháchHàngToolStripMenuItem;
        private System.Windows.Forms.TextBox txtMS;
        private System.Windows.Forms.ToolStripMenuItem thêmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmKháchHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmHợpĐồngToolStripMenuItem;
    }
}