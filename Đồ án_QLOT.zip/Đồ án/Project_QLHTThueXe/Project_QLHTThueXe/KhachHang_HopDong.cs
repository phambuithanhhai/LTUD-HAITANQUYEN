﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_QLHTThueXe
{
    public partial class frmHopDong : Form
    {
        public frmHopDong()
        {
            InitializeComponent();
        }

        private void frmHopDong_FormClosing(object sender, FormClosingEventArgs e)//thông báo thoát
        {
           if( MessageBox.Show("Bạn có muốn thoát không?","Thông báo",MessageBoxButtons.YesNo,MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel =true;
        }
        private void thoatToolStripMenuItem_Click(object sender, EventArgs e)//nút thoát
        {
            this.Close();
        }

        private void txtSP_TextChanged(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtSP, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();

        }

        private void txtSoHD_Leave(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtSoHD, "Bạn phãi nhập Số HD");
            else
                this.errorProvider1.Clear();
        }

        private void txtTen_Leave(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtTen, "Bạn phải nhập Tên KH");
            else
                this.errorProvider1.Clear();
        }

        private void txtMSThue_Leave(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtMSThue, "Bạn phải nhập Mã Số Thuế");
            else
                this.errorProvider1.Clear();
        }

        private void txtDiaChi_Leave(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtDiaChi, "Bạn phải nhập Địa chỉ");
            else
                this.errorProvider1.Clear();
        }

        private void txtSDT_TextChanged(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtSDT, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }

        private void txtNgheNghiep_Leave(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNgheNghiep, "Bạn phải nhập Nghề Nghiệp");
            else
                this.errorProvider1.Clear();
        }

        private void txtCMND_TextChanged(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtCMND, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }
        private void txtGPLX_TextChanged(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtGPLX, "Bạn phải nhập số!!!");
            else
                this.errorProvider1.Clear();
        }
        //điều kiện nhập
        private void txtNoiCapCMND_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNoiCapCMND, "Bạn phải nhập Nơi Cấp CMND");
            else
                this.errorProvider1.Clear();
        }

        private void txtNoiCapGPLX_Leave(object sender, EventArgs e)//điều kiện nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNoiCapGPLX, "Bạn phải nhập Nơi Cấp");
            else
                this.errorProvider1.Clear();
        }
        clsDataBase db = new clsDataBase();
        private void frmHopDong_Load(object sender, EventArgs e)//load bảng vào datadridwiew
        {
            dgvXe.DataSource = db.getDataTable("XE");
            dgvKH_HD.DataSource = db.getDataTable("KHACHHANG");
        }
        
       
        private void txtLocHD_TextChanged(object sender, EventArgs e) //tim hop dong theo so hop dong
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_timKiemHD", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@SOHOPDONG", txtLocHD.Text));
                // sqldataAdapter
                SqlDataAdapter daHD = new SqlDataAdapter(cmd);//tạo đối tượng SqlAdapter là cầu nối giữa dataset và datasource để thực hiện công việc như đọc hay cập nhật dữ liệu
                DataTable dtHD = new DataTable();//khởi tạo đối tượng datatable
                daHD.Fill(dtHD);// fill dữ liệu vào datatable
                dgvKH_HD.DataSource = dtHD;
            }
            catch (Exception ex)
            {

                MessageBox.Show("Không tìm thấy", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void txtLocKH_TextChanged(object sender, EventArgs e) ///tim khang hang theo ma khach hang
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_timKiemKH", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG ", txtLocKH.Text));
                // sqldataAdapter
                SqlDataAdapter daKH = new SqlDataAdapter(cmd);//tạo đối tượng SqlAdapter là cầu nối giữa dataset và datasource để thực hiện công việc như đọc hay cập nhật dữ liệu
                DataTable dtKH = new DataTable();//khởi tạo đối tượng datatable
                daKH.Fill(dtKH);// fill dữ liệu vào datatable
                dgvKH_HD.DataSource = dtKH;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không tìm thấy", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
        int index;
        private void dgvKH_HD_Click(object sender, EventArgs e) //click add thong tin khach hang
        {
            index = dgvKH_HD.CurrentRow.Index;
            txtMAKH.Text = dgvKH_HD.Rows[index].Cells[0].Value.ToString();
            txtTen.Text = dgvKH_HD.Rows[index].Cells[1].Value.ToString();
            txtDiaChi.Text = dgvKH_HD.Rows[index].Cells[2].Value.ToString();
            txtSDT.Text = dgvKH_HD.Rows[index].Cells[3].Value.ToString();
            txtCMND.Text = dgvKH_HD.Rows[index].Cells[4].Value.ToString();
            dateNgayCapCMND.Text = dgvKH_HD.Rows[index].Cells[5].Value.ToString();
            txtNoiCapCMND.Text = dgvKH_HD.Rows[index].Cells[6].Value.ToString();
            txtGPLX.Text = dgvKH_HD.Rows[index].Cells[7].Value.ToString();
            dateNoiCapGPLX.Text = dgvKH_HD.Rows[index].Cells[8].Value.ToString();
            txtNoiCapGPLX.Text = dgvKH_HD.Rows[index].Cells[9].Value.ToString();
            txtNgheNghiep.Text = dgvKH_HD.Rows[index].Cells[10].Value.ToString();
        }

        private void sửaToolStripMenuItem_Click(object sender, EventArgs e) //sua  thong tin khách hàng 
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_updateKhachHang", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG", txtMAKH.Text));
                cmd.Parameters.Add(new SqlParameter("@HOTEN ", txtTen.Text));
                cmd.Parameters.Add(new SqlParameter("@DIACHI", txtDiaChi.Text));
                cmd.Parameters.Add(new SqlParameter("@STD", txtSDT.Text));
                cmd.Parameters.Add(new SqlParameter("@CMND", txtCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYCAPCMND", dateNgayCapCMND.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NOICAPCMND ", txtNoiCapCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@SOGPLX ", txtGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYCAPGPLX ", dateNoiCapGPLX.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NOICAPGPLX ", txtNoiCapGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NGHENGHIEP ", txtNgheNghiep.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Sửa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgvKH_HD.DataSource = db.getDataTable("KHACHHANG");
                }
                else
                {
                    MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã khách hàng", "Thông Báo");
            }
            finally
            {
                conn.Close();
            }
        }

        private void kLưuToolStripMenuItem_Click(object sender, EventArgs e)// xem thông tin hợp đồng
        {
            frmXem x = new frmXem();
            x.Show();
        }

        private void dgvXe_Click(object sender, EventArgs e) //click vào add Maxe
        {
            index = dgvXe.CurrentRow.Index;
            txtMS.Text = dgvXe.Rows[index].Cells[0].Value.ToString();
        }

        private void thêmKháchHàngToolStripMenuItem_Click(object sender, EventArgs e)//thêm khách hàng
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themKH", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG", txtMAKH.Text));
                cmd.Parameters.Add(new SqlParameter("@HOTEN ", txtTen.Text));
                cmd.Parameters.Add(new SqlParameter("@DIACHI", txtDiaChi.Text));
                cmd.Parameters.Add(new SqlParameter("@STD", txtSDT.Text));
                cmd.Parameters.Add(new SqlParameter("@CMND", txtCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYCAPCMND", dateNgayCapCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@NOICAPCMND ", txtNoiCapCMND.Text));
                cmd.Parameters.Add(new SqlParameter("@SOGPLX ", txtGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYCAPGPLX ", dateNoiCapGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NOICAPGPLX ", txtNoiCapGPLX.Text));
                cmd.Parameters.Add(new SqlParameter("@NGHENGHIEP ", txtNgheNghiep.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("thêm thành công", "thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgvKH_HD.DataSource = db.getDataTable("KHACHHANG");

                }
                else
                {
                    MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!! Bạn đã nhập sai thông tin hoặc trùng Mã khách hàng", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }
        

        private void thêmHợpĐồngToolStripMenuItem_Click(object sender, EventArgs e)//thêm hợp đồng
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_Kiemtra", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "YES"));
                SqlDataReader data = cmd.ExecuteReader();
                if (data.Read() == true) //kiểm tra tình trạng xe
                {
                    MessageBox.Show("Không thể thêm!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    themHD();//gọi hàm thêm hợp đồng
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
        public void themHD()//thêm thông tin hợp đồng
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themHopdong", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOPHIEU", txtSP.Text));
                cmd.Parameters.Add(new SqlParameter("@SOHOPDONG ", txtSoHD.Text));
                cmd.Parameters.Add(new SqlParameter("@LOAIHINH", cbLH.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYTHUE ", dateNgayThue.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NGAYTRA", dateNgayTra.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NGAYKYHOPDONG", dateNgayKiHD.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@MASOTHUE ", txtMSThue.Text));
                cmd.Parameters.Add(new SqlParameter("@THANHTIEN ", txtTT.Text));
                cmd.Parameters.Add(new SqlParameter("@GHICHU ", rtGhiChu.Text));
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG ", txtMAKH.Text));
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));
                cmd.Parameters.Add(new SqlParameter("@TRANGTHAI", "ĐANG THUÊ"));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("thêm thành công", "thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    updateTinhTrang();//gọi hàm update tình trạng thì xe dc thuê
                }
                else
                {
                    MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bạn đã nhập sai thông tin hoặc trùng mã hợp đồng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
        private void xóaToolStripMenuItem_Click(object sender, EventArgs e)//xóa thông tin khách hàng
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_xoaKhachhang", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAKHACHHANG", txtMAKH.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("xóa thành công", "thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgvKH_HD.DataSource = db.getDataTable("KHACHHANG");
                }
                else
                {
                    MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!!không thể xóa thông tin khách hàng", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                conn.Close();
            }
        }

        public void updateTinhTrang()//thay doi tinh trang YES khi xe duoc thue
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_updateTinhTrang", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMS.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "YES"));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    dgvXe.DataSource = db.getDataTable("XE");
                }
                else
                {
                    MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể thay đổi tình trạng xe", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);// thong bao loi
            }
            finally
            {
                conn.Close();
            }


        }

        

       

        

       

        
      
    



      

      

      

     


   

       


      

      

    }
}
