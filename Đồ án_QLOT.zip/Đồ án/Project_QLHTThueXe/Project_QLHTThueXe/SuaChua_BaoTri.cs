﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
namespace Project_QLHTThueXe
{
    public partial class frmSuaChua : Form
    {
        public frmSuaChua()
        {
            InitializeComponent();
        }
        clsDataBase db = new clsDataBase();//goi class
        private void SuaChua_BaoTri_FormClosing(object sender, FormClosingEventArgs e)///thông báo thoát
        {
            if (MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel = true;
        }

        private void txtMhd_Leave(object sender, EventArgs e)//kiểm tra giá trị nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
            {
                this.errorProvider1.SetError(txtMhd, "You must enter Your Mhd");

            }
            else
                this.errorProvider1.Clear();
        }

        private void txtNcc_Leave(object sender, EventArgs e) //kiểm tra giá trị nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
            {
                this.errorProvider1.SetError(txtNcc, "You must enter your nha cung cap");

            }
            else
                this.errorProvider1.Clear();


        }

        private void txtMs_Leave(object sender, EventArgs e) //kiểm tra giá trị nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtMs, "You must enter your number");
            else
                this.errorProvider1.Clear();
        }


        private void txtNd_Leave(object sender, EventArgs e) //kiểm tra giá trị nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtNd, "You must enter your text");
            else
                this.errorProvider1.Clear();
        }

        private void txtTt_Leave(object sender, EventArgs e) //kiểm tra giá trị nhập
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                this.errorProvider1.SetError(txtTt, "This is not invalid number");
            else
                this.errorProvider1.Clear();


        }

        private void thoa1ToolStripMenuItem_Click(object sender, EventArgs e) //nút thoát
        {
            this.Close();
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------//

        private void frmSuaChua_Load(object sender, EventArgs e)//load thong tin
        {
            drvSC.DataSource = db.getDataTable("SUACHUABAOTRI");//load thong tin bang sua chua lên drvSC
            drvXe.DataSource = db.getDataTable("XE");//load thong tin bang xe len drvXe

        }

       
        public void themSuaChua()//hàm thêm sữa chữa
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_themSuaChua", conn);//gọi hàm sữa chữa
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAHOADON", txtMhd.Text));
                cmd.Parameters.Add(new SqlParameter("@NHACUNGCAP", txtNcc.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYSUACHUA", dateSc.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NGAYHOANTAT", dateHt.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMs.Text));
                cmd.Parameters.Add(new SqlParameter("@NOIDUNGCHITIET", txtNd.Text));
                cmd.Parameters.Add(new SqlParameter("@TONGTIEN", txtTt.Text));
                cmd.Parameters.Add(new SqlParameter("@THANHTOAN", cbThanhToan.Text));

                if (cmd.ExecuteNonQuery() > 0)//kiem tra gia trị 
                {
                    MessageBox.Show("Thêm thành công", "thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    drvSC.DataSource = db.getDataTable("SUACHUABAOTRI");//load lại thông tin bảng xe
                    updateTinhTrang();//update tình trạng YES khi xe được thuê
                }
                else
                {
                    MessageBox.Show("không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!!Xe đã được thuê hoặc trùng mã hóa đơn", "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Question);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        int index;
        private void drvSC_Click(object sender, EventArgs e)//click add thong tin vào form
        {
            index = drvSC.CurrentRow.Index;
            txtMhd.Text = drvSC.Rows[index].Cells[0].Value.ToString();
            txtNcc.Text = drvSC.Rows[index].Cells[1].Value.ToString();
            dateSc.Text = drvSC.Rows[index].Cells[2].Value.ToString();
            dateHt.Text = drvSC.Rows[index].Cells[3].Value.ToString();
            txtMs.Text = drvSC.Rows[index].Cells[4].Value.ToString();
            txtNd.Text = drvSC.Rows[index].Cells[5].Value.ToString();
            txtTt.Text = drvSC.Rows[index].Cells[6].Value.ToString();
            cbThanhToan.Text = drvSC.Rows[index].Cells[7].Value.ToString();

        }

        private void dgvXe_Click(object sender, EventArgs e)//click add lấy ma so xe
        {
            index = drvXe.CurrentRow.Index;
            txtMs.Text = drvXe.Rows[index].Cells[0].Value.ToString();

        }


        public void updateTinhTrang()//thay doi tình trạng YES xe khi xe được thuê
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_updateTinhTrang", conn);// gọi store
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMs.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "YES"));//thay đổi tình trạng YES
                if (cmd.ExecuteNonQuery() > 0) 
                {
                    drvXe.DataSource = db.getDataTable("XE");//load lại thông tin bảng xe
                }
                else
                {
                    MessageBox.Show("Không thành công","Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
            }
            catch (Exception ex)
            {     
                MessageBox.Show("Lỗi !!!", "Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Question);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void thêmToolStripMenuItem_Click(object sender, EventArgs e)//thêm thông tin sửa chữa xe
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_Kiemtra", conn);//goi store kiem tra
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMs.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "YES"));
                SqlDataReader data = cmd.ExecuteReader();//kiem tra gia tri
                if (data.Read() == true)//Kiem tra nếu tình trạng xe là YES
                {
                    MessageBox.Show("Không thể thêm!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
                else
                {
                    themSuaChua();//goi hàm thêm sua chữa
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!!", "Thong bao");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void xóaToolStripMenuItem_Click(object sender, EventArgs e)//xóa thông tin sữa chữa
        {
             // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_xoaBaoTri", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAHOADON", txtMhd.Text));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Xóa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    updateTinhTrang1();//cập nhật tình trạng xe NO khi xóa
                    drvSC.DataSource = db.getDataTable("SUACHUABAOTRI");
                }
                else
                {
                    MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Xe đang được thuê hoặc sửa chữa!Không thể xóa xe", "Thông báo");// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }

        private void sửaToolStripMenuItem_Click(object sender, EventArgs e)//sửa thông tin sữa chữa
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_Kiemtra", conn);//goi store kiem tra
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMs.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "YES"));
                SqlDataReader data = cmd.ExecuteReader();//kiem tra 
                if (data.Read() == true)//neu Tình trạng YES
                {
                    MessageBox.Show("Không thể sửa!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
                else
                {
                    updateSuaChua();//goi hàm update sua chữa
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
        public void updateSuaChua()//hàm update thông tin sửa chữa
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_updateSuaChua", conn);//gọi store update hàm sữa chữa
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MAHOADON", txtMhd.Text));
                cmd.Parameters.Add(new SqlParameter("@NHACUNGCAP", txtNcc.Text));
                cmd.Parameters.Add(new SqlParameter("@NGAYSUACHUA", dateSc.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@NGAYHOANTAT", dateHt.Value.ToString()));
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMs.Text));
                cmd.Parameters.Add(new SqlParameter("@NOIDUNGCHITIET", txtNd.Text));
                cmd.Parameters.Add(new SqlParameter("@TONGTIEN", txtTt.Text));
                cmd.Parameters.Add(new SqlParameter("@THANHTOAN", cbThanhToan.Text));

                if (cmd.ExecuteNonQuery() > 0)//kiem tra gia trị 
                {
                    MessageBox.Show("Sửa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    drvSC.DataSource = db.getDataTable("SUACHUABAOTRI");//load lại thông tin bảng xe
                    updateTinhTrang();//update tình trạng YES cập nhật xe được thuê
                }
                else
                {
                    MessageBox.Show("Không thành công", "thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!!Xe đã được thuê hoặc mã trùng hóa đơn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
        public void updateTinhTrang1()//thay doi tình trạng xe bị xóa
        {
            // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_updateTinhTrang", conn);// gọi store
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@MASOXE", txtMs.Text));
                cmd.Parameters.Add(new SqlParameter("@TINHTRANG", "NO"));//thay đổi tình trạng NO
                if (cmd.ExecuteNonQuery() > 0)
                {
                    drvXe.DataSource = db.getDataTable("XE");//load lại thông tin bảng xe
                }
                else
                {
                    MessageBox.Show("Không thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);// thong bao loi
            }
            finally
            {
                conn.Close();
            }
        }
   






    }
     
    }
