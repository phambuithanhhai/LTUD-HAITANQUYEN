﻿namespace Project_QLHTThueXe
{
    partial class frmQuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Sửa Chữa");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Hợp Đồng");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Xe");
            this.label1 = new System.Windows.Forms.Label();
            this.tree = new System.Windows.Forms.TreeView();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.themToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hopDongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suaChuaBaoTriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gioiThieuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(302, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 31);
            this.label1.TabIndex = 18;
            this.label1.Text = "Quản Lý Hệ Thống Thuê Xe";
            // 
            // tree
            // 
            this.tree.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tree.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tree.LabelEdit = true;
            this.tree.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.tree.Location = new System.Drawing.Point(24, 95);
            this.tree.Name = "tree";
            treeNode1.Name = "SuaChua";
            treeNode1.Text = "Sửa Chữa";
            treeNode2.Name = "HopDong";
            treeNode2.Text = "Hợp Đồng";
            treeNode3.Name = "Xe";
            treeNode3.Text = "Xe";
            this.tree.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            this.tree.ShowPlusMinus = false;
            this.tree.Size = new System.Drawing.Size(321, 441);
            this.tree.TabIndex = 16;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.themToolStripMenuItem,
            this.gioiThieuToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
            this.menuStrip2.Size = new System.Drawing.Size(959, 29);
            this.menuStrip2.TabIndex = 19;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // themToolStripMenuItem
            // 
            this.themToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hopDongToolStripMenuItem,
            this.xeToolStripMenuItem,
            this.suaChuaBaoTriToolStripMenuItem});
            this.themToolStripMenuItem.Name = "themToolStripMenuItem";
            this.themToolStripMenuItem.Size = new System.Drawing.Size(94, 23);
            this.themToolStripMenuItem.Text = "Thêm mới";
            // 
            // hopDongToolStripMenuItem
            // 
            this.hopDongToolStripMenuItem.Name = "hopDongToolStripMenuItem";
            this.hopDongToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.hopDongToolStripMenuItem.Text = "Hợp Đồng";
            this.hopDongToolStripMenuItem.Click += new System.EventHandler(this.hopDongToolStripMenuItem_Click);
            // 
            // xeToolStripMenuItem
            // 
            this.xeToolStripMenuItem.Name = "xeToolStripMenuItem";
            this.xeToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.xeToolStripMenuItem.Text = "Xe";
            this.xeToolStripMenuItem.Click += new System.EventHandler(this.xeToolStripMenuItem_Click);
            // 
            // suaChuaBaoTriToolStripMenuItem
            // 
            this.suaChuaBaoTriToolStripMenuItem.Name = "suaChuaBaoTriToolStripMenuItem";
            this.suaChuaBaoTriToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.suaChuaBaoTriToolStripMenuItem.Text = "Sửa Chữa - Bảo Trì";
            this.suaChuaBaoTriToolStripMenuItem.Click += new System.EventHandler(this.suaChuaBaoTriToolStripMenuItem_Click);
            // 
            // gioiThieuToolStripMenuItem
            // 
            this.gioiThieuToolStripMenuItem.Name = "gioiThieuToolStripMenuItem";
            this.gioiThieuToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.gioiThieuToolStripMenuItem.Text = "Giới thiệu";
            this.gioiThieuToolStripMenuItem.Click += new System.EventHandler(this.gioiThieuToolStripMenuItem_Click);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(353, 95);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(595, 441);
            this.dgv.TabIndex = 20;
            // 
            // frmQuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 550);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tree);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmQuanLy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Thuê Xe";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmQuanLy_FormClosing);
            this.Load += new System.EventHandler(this.frmQuanLy_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView tree;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem themToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hopDongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suaChuaBaoTriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gioiThieuToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv;
    }
}