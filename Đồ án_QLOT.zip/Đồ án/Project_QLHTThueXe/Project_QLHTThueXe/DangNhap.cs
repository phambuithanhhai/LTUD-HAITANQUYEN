﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
namespace Project_QLHTThueXe
{
    public partial class frmDangNhap : Form
    {
        //Khởi tạo class kết nối cơ sở dữ liệu
        clsDataBase db = new clsDataBase();
        public frmDangNhap()
        {
            InitializeComponent();
        }
        //xét điều kiện nhập Tài Khoản
        private void txtTaiKhoan_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtTaiKhoan, "You must enter Your name");//thong bao de nhap
            else
                this.errorProvider1.Clear();

        }
        //Thông báo khi Thoát
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r;
            r = MessageBox.Show("Do you want to close?", "Exit",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button1);
            if (r == DialogResult.No)
                e.Cancel = true;
        }
        //button Thoát
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //button Đăng nhập
       private void btnDangNhap_Click(object sender, EventArgs e)//kiem tra dang nhap
        {
           // ket noi db
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=QLOTO;Integrated Security=True");//(duong dan den co so du lieu)
            // mo ket noi
            try
            {
                conn.Open();
                // command
                SqlCommand cmd = new SqlCommand("sp_DangNhap", conn);// Khai báo và khởi tạo đối tượng Command, truyền vào tên thủ tục tương ứng
                cmd.CommandType = CommandType.StoredProcedure;// Khai báo kiểu thực thi là Thực thi thủ tục
                cmd.Parameters.Add(new SqlParameter("@USERNAME", txtTaiKhoan.Text));// Gán giá trị cho tham số @USERNAME - là tên tham số được tạo trong thủ tục
                cmd.Parameters.Add(new SqlParameter("@MATKHAU", txtPass.Text));// Gán giá trị cho tham số @MATKHAU - là tên tham số được tạo trong thủ tục
                // Thực thi thủ tục
                int x = (int)cmd.ExecuteScalar();//trả về 1 giá trị đơn
                if (x > 0)
                {
                    MessageBox.Show("Đăng nhập thành công","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Information);//Thông báo đăng nhập thành công
                    this.Close();//thoát khỏi form Dang Nhap
                    frmQuanLy ql = new frmQuanLy();//khởi tạo from Quan Ly
                    ql.Show();//Show from Quan Ly
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Tài khoản hoặc mật khẩu sai", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Question);//Thong bao sai
            }
            finally
            {
                conn.Close();//Đóng kết nối
            }
        }

      

     

         
    }
}
