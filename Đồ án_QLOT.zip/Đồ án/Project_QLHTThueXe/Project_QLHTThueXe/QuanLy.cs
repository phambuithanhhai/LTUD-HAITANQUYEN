﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project_QLHTThueXe
{
    public partial class frmQuanLy : Form
    {
        clsDataBase db = new clsDataBase();
        public frmQuanLy()
        {
            InitializeComponent();
        }

        private void hopDongToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHopDong hd = new frmHopDong();
            hd.Show();
        }

        private void xeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmXe xe = new frmXe();
            xe.Show();
        }

        private void suaChuaBaoTriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuaChua sc = new frmSuaChua();
            sc.Show();
        }

        private void gioiThieuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string kq = "";
            kq += "Phần mềm quản lí cho thuê xe ô tô\n";
            kq += "Website: Congtyphanmem.com\n";
            kq += "Design: Congtyphanmem\n";
            kq += "SDT: 0123456789\n";
            kq += "Địa chỉ: 23 Võ Văn Ngân, Phường Linh Chiểu, Quận Thủ Đức, Tp. Hồ Chí Minh";

            MessageBox.Show(kq, "Thông tin");
        }

        private void frmQuanLy_Load(object sender, EventArgs e)
        {
            dgv.DataSource = db.getDataTable("XE");
        }

        private void frmQuanLy_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel = true;
        }

 


        }
    }

   
   

       
       

